import { Language, PresentationPlanResponse, Slide } from '../types';
import { DEFAULT_THEME_ID, getTheme } from '../utils/themes';

const parseJsonSafe = async (response: Response): Promise<unknown> => {
  const text = await response.text();
  if (!text || !text.trim()) {
    return null;
  }
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
};

const isPlainObject = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

const normalizeSlide = (raw: unknown): Slide | null => {
  if (!isPlainObject(raw)) return null;
  const title = typeof raw.title === 'string' ? raw.title : '';
  const content = Array.isArray(raw.content)
    ? raw.content.filter((item): item is string => typeof item === 'string')
    : [];

  if (!title.trim() && content.length === 0) return null;

  return {
    title,
    sectionTag: typeof raw.sectionTag === 'string' ? raw.sectionTag : undefined,
    content: content.length > 0 ? content : [''],
    layout: typeof raw.layout === 'string' ? (raw.layout as Slide['layout']) : 'split_left',
    visual: isPlainObject(raw.visual) ? (raw.visual as unknown as Slide['visual']) : undefined,
    visualMotif:
      typeof raw.visualMotif === 'string'
        ? (raw.visualMotif as Slide['visualMotif'])
        : 'orbital',
    speakerNotes: typeof raw.speakerNotes === 'string' ? raw.speakerNotes : '',
    imageData: typeof raw.imageData === 'string' ? raw.imageData : undefined,
  };
};

const MAX_PLAN_PAYLOAD_BYTES = 128 * 1024;
const MAX_REFINE_PAYLOAD_BYTES = 256 * 1024;

const getUtf8ByteLength = (text: string): number => {
  if (typeof TextEncoder !== 'undefined') {
    return new TextEncoder().encode(text).length;
  }
  return text.length * 2;
};

const serializeAndValidatePayload = (
  data: unknown,
  maxBytes: number,
  label: string
): string => {
  const json = JSON.stringify(data);
  const byteLength = getUtf8ByteLength(json);
  if (byteLength > maxBytes) {
    const sizeKb = Math.round(byteLength / 1024);
    const limitKb = Math.round(maxBytes / 1024);
    throw new Error(
      `${label} request payload is too large (${sizeKb} KB, max ${limitKb} KB). Please shorten the text and try again.`
    );
  }
  return json;
};

const sanitizeSlideForRefine = (slide: Slide): Omit<Slide, 'imageData'> => ({
  title: typeof slide.title === 'string' ? slide.title : '',
  ...(typeof slide.sectionTag === 'string' ? { sectionTag: slide.sectionTag } : {}),
  content: Array.isArray(slide.content)
    ? slide.content.filter((item): item is string => typeof item === 'string')
    : [],
  layout: slide.layout,
  ...(slide.visual !== undefined ? { visual: slide.visual } : {}),
  ...(slide.visualMotif !== undefined ? { visualMotif: slide.visualMotif } : {}),
  ...(typeof slide.speakerNotes === 'string' ? { speakerNotes: slide.speakerNotes } : {}),
});

export const generatePresentationPlan = async (
  topic: string,
  slideCount: number,
  planCount: number,
  language: Language,
  additionalInfo?: string
): Promise<PresentationPlanResponse> => {
  const body = serializeAndValidatePayload(
    {
      topic,
      slideCount,
      planCount,
      language,
      additionalInfo,
    },
    MAX_PLAN_PAYLOAD_BYTES,
    'Presentation generation'
  );

  const response = await fetch('/api/presentation/plan', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body,
  });

  const contentType = response.headers.get('content-type') || 'unknown';
  const payload = await parseJsonSafe(response);

  if (response.status === 413) {
    const message =
      isPlainObject(payload) && typeof payload.error === 'string'
        ? payload.error
        : 'Presentation request payload is too large (HTTP 413). Please shorten your topic or instructions.';
    throw new Error(message);
  }

  if (!response.ok) {
    const message =
      isPlainObject(payload) && typeof payload.error === 'string'
        ? payload.error
        : `Presentation request failed (HTTP ${response.status}).`;
    throw new Error(message);
  }

  if (!isPlainObject(payload)) {
    throw new Error(
      `Unexpected server response (HTTP ${response.status}, ${contentType}).`
    );
  }

  const rawSlides = Array.isArray(payload.slides) ? payload.slides : [];
  const slides = rawSlides
    .map(normalizeSlide)
    .filter((slide): slide is Slide => slide !== null);

  if (slides.length === 0) {
    throw new Error('No slides were generated for this topic. Please try again.');
  }

  const resolvedTheme = getTheme(
    typeof payload.themeId === 'string' ? payload.themeId : DEFAULT_THEME_ID
  );

  const rawStats = isPlainObject(payload.usageStats) ? payload.usageStats : null;

  return {
    themeId: resolvedTheme.id,
    slides,
    usageStats: {
      model: rawStats && typeof rawStats.model === 'string' ? rawStats.model : 'gemini-3.1-flash-lite',
      inputTokens: rawStats && typeof rawStats.inputTokens === 'number' ? rawStats.inputTokens : 0,
      outputTokens: rawStats && typeof rawStats.outputTokens === 'number' ? rawStats.outputTokens : 0,
      totalTokens: rawStats && typeof rawStats.totalTokens === 'number' ? rawStats.totalTokens : 0,
    },
  };
};

export const refineSlideContent = async (
  topic: string,
  slide: Slide,
  instruction: string,
  language: Language
): Promise<Slide> => {
  const sanitizedSlide = sanitizeSlideForRefine(slide);
  const body = serializeAndValidatePayload(
    {
      topic,
      slide: sanitizedSlide,
      instruction,
      language,
    },
    MAX_REFINE_PAYLOAD_BYTES,
    'Slide refinement'
  );

  const response = await fetch('/api/presentation/refine-slide', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body,
  });

  const contentType = response.headers.get('content-type') || 'unknown';
  const payload = await parseJsonSafe(response);

  if (response.status === 413) {
    const message =
      isPlainObject(payload) && typeof payload.error === 'string'
        ? payload.error
        : 'Slide refinement payload is too large (HTTP 413). Please shorten the slide text and try again.';
    throw new Error(message);
  }

  if (!response.ok) {
    const message =
      isPlainObject(payload) && typeof payload.error === 'string'
        ? payload.error
        : `Failed to update slide (HTTP ${response.status}).`;
    throw new Error(message);
  }

  if (!isPlainObject(payload) || !isPlainObject(payload.slide)) {
    throw new Error(
      `Unexpected slide update response (HTTP ${response.status}, ${contentType}).`
    );
  }

  const normalized = normalizeSlide(payload.slide);
  if (!normalized) {
    throw new Error('Server returned an empty slide update.');
  }

  return {
    ...slide,
    ...normalized,
    imageData: slide.imageData,
  };
};
