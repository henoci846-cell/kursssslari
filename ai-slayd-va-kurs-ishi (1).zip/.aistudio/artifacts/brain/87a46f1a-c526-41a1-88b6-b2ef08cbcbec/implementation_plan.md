# AI Slide Creator — Full-Stack Upgrade & Studio Polish

Upgrade the AI Slide Creator ("AI Slayd Yaratuvchi") into a full-stack presentation studio with dedicated server-side Gemini endpoints, upgraded Gemini 4 text planning and custom slide illustration generation, inline slide editing, and a refined multi-language interface (`uz`, `en`, `ru`).

## User Review & Critical Decisions

> [!IMPORTANT]
> Because clarifying questions were skipped, this plan uses the recommended defaults below. Review before approving:
> - **Server-Side Gemini API Architecture**: Moves all AI generation calls to backend API endpoints powered by the server environment key (`Settings > Secrets`), removing client-side key bundles and unused modal prompts.
> - **Upgraded Models & Paid Image Generation**: Uses `gemini-4-hydrogen` for structured multi-language slide planning and `gemini-3.1-flash-lite-image` for custom slide photography and background textures. Note that `gemini-3.1-flash-lite-image` requires selecting a paid API key during implementation.
> - **Interactive Studio Enhancements**: Adds inline slide text editing and a quick slide navigator rail before PowerPoint (`.pptx`) export while preserving all existing themes, layouts, and `uz` / `en` / `ru` translations.

---

## 1. Overview & Core Concept

- **What It Does**: Users enter a presentation topic, optional stylistic guidance, language (`O'zbek`, `English`, `Русский`), slide count (`10–30`), and outline plan count (`3–5`). The application generates a structured multi-slide deck with tailored themes, visual backgrounds, and slide illustrations, lets the user review, edit, and re-theme slides in an interactive 16:9 studio, and exports a ready-to-present `.pptx` file.
- **Target Audience / Persona**: Students, educators, analysts, and professionals preparing structured Uzbek, English, or Russian slide decks quickly.
- **Key Value**: Reliable full-stack AI generation without browser timeout/key-config friction, sharper visual polish, and direct pre-export slide editing so users never have to fix minor text tweaks after downloading PowerPoint files.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Deck Setup (Zero State)**: Clean, centered creation workspace with language switcher (`uz` / `en` / `ru`), topic input, optional tone/content instructions, and slide/outline selectors.
  2. **Staged Generation Feedback**: Dedicated progress view transitioning from outline planning (`Reja tuzilmoqda...`) to per-slide illustration progress (`Rasmlar: X / Y`) with tabular numeric counters and clear retry recovery on errors.
  3. **Presentation Studio (Ready State)**: Full-width workspace featuring a compact top toolbar (`New Topic`, slide counter, `PowerPoint (.pptx)` export), a collapsible left slide-outline rail for instant jumping, the central 16:9 slide stage with live inline text editing, and a bottom navigation & theme switcher bar (7 curated themes).
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Crisp, editorial productivity studio — clean neutral surfaces with focused indigo primary actions and theme-driven slide canvas previews.
  - *Color Palette & Mood* (60-30-10 discipline):
    - Dominant Neutral Canvas (60%): `--bg-canvas` (`#F8FAFC`)
    - Structural Surfaces (30%): `--surface-card` (`#FFFFFF`), `--border-hairline` (`#E2E8F0`), `--text-primary` (`#0F172A`), `--text-muted` (`#475569`)
    - Accent Budget (10%): `--accent-primary` (`#4F46E5`) for primary actions, active states, and progress indicators; semantic `--state-error` (`#DC2626`) paired with explicit icons/messages.
  - *Typography & Hierarchy*: Replace default `Inter` with `Plus Jakarta Sans` (600–700) for display titles and UI headings paired with `DM Sans` (400–500) for clean body readability, plus `tabular-nums` on all slide counters and progress indicators.
  - *Component Styling & Layout*: Single-elevation flat cards with `1px` hairline borders, `whitespace-nowrap` single-line toolbar controls, balanced 1440px desktop spacing, and mobile-safe responsive slide containers without `window.alert` popups (replaced by inline error banners).
- **Interactive Feedback & Motion**: Fast `150–200ms` transitions on hover, slide switching, and theme selection; inline toast/banner feedback if `.pptx` export or generation encounters an issue; keyboard `ArrowLeft` / `ArrowRight` navigation (paused automatically when typing inside an editable slide field).

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Server-Side Express Proxy for Gemini Calls**
  - *Chosen Approach*: Run an Express server alongside Vite in development and production, exposing dedicated `/api/presentation/plan` and `/api/presentation/image` endpoints that invoke `@google/genai`.
  - *Why*: Keeps API credentials strictly on the server via `Settings > Secrets`, removes unused client API-key modals and legacy external error-reporting webhooks, and standardizes retry/error propagation.
  - *Alternatives Considered*: Keeping direct browser calls to Gemini. Passed over because full-stack backend routes provide reliable secret management, cleaner error handling, and proper server telemetry headers.
- **Decision 2 — Upgraded Gemini 4 Planning + Flash Lite Image Generation**
  - *Chosen Approach*: Use `gemini-4-hydrogen` with structured JSON `responseSchema` for presentation outlines and `gemini-3.1-flash-lite-image` for slide visuals and subtle backgrounds.
  - *Why*: `gemini-4-hydrogen` delivers fast, accurate multi-language structured JSON output, while `gemini-3.1-flash-lite-image` produces crisp 16:9/4:3 photography without text artifacts.
  - *Alternatives Considered*: Keeping legacy preview/2.5 model identifiers. Passed over to align with current supported models and higher reliability.
- **Decision 3 — Client-Side Session State + Inline Slide Editing**
  - *Chosen Approach*: Keep active deck state in React memory with inline editing for slide titles and bullet/paragraph text, exporting directly to `.pptx` in the browser via `pptxgenjs`.
  - *Why*: Avoids unnecessary database setup for single-session slide creation while letting users refine generated copy immediately before PowerPoint export.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                          Browser Client (React)                         │
│                                                                         │
│  ┌──────────────┐    ┌──────────────────┐    ┌───────────────────────┐  │
│  │  Deck Setup  │───▶│  Progress View   │───▶│  Presentation Studio  │  │
│  │  (uz/en/ru)  │    │ (Plan -> Images) │    │  - Slide Rail         │  │
│  └──────────────┘    └──────────────────┘    │  - Editable 16:9 Deck │  │
│         │                     ▲              │  - 7-Theme Switcher   │  │
│         │                     │              │  - .pptx Exporter     │  │
│         ▼                     │              └───────────────────────┘  │
│  ┌────────────────────────────┴──────────────────────────────────────┐  │
│  │               Client API Service (fetch /api/*)                   │  │
│  └────────────────────────────┬──────────────────────────────────────┘  │
└───────────────────────────────┼─────────────────────────────────────────┘
                                │ HTTP POST JSON
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      Node / Express Backend Server                      │
│                                                                         │
│  ┌──────────────────────────────┐  ┌─────────────────────────────────┐  │
│  │ POST /api/presentation/plan  │  │ POST /api/presentation/image    │  │
│  │ - Input validation           │  │ - Input validation              │  │
│  │ - gemini-4-hydrogen + schema │  │ - gemini-3.1-flash-lite-image   │  │
│  └──────────────┬───────────────┘  └────────────────┬────────────────┘  │
│                 └──────────────────┬────────────────┘                   │
│                                    ▼                                    │
│                 Shared Server Gemini Client (`@google/genai`)           │
│                 Reads `process.env.GEMINI_API_KEY` on server            │
└─────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - `PresentationRequest`: `{ topic, slideCount, planCount, language, additionalInfo }`
  - `Slide`: `{ title, content: string[], layout, imagePrompt?, imageData? }`
  - `Theme`: `{ id, name, colors: { primary, secondary, accent, background, text, textLight }, font }`
  - `AppStatus`: `IDLE` -> `GENERATING_PLAN` -> `GENERATING_IMAGES` -> `READY` | `ERROR`
- **Interactive Component & State Mapping**:
  - **Setup Form**: Validates non-empty topic, binds `slideCount`, `planCount`, `language`, and `additionalInfo`, and triggers the async generation sequence.
  - **Generation Pipeline**: Calls `/api/presentation/plan` first to populate `theme`, `slides`, and `backgroundVisualPrompt`, then generates the background image and per-slide images sequentially via `/api/presentation/image`, updating progress (`current / total`) after each slide without aborting the deck if an individual image fails.
  - **Studio & Slide Editor**: Switching slides via the outline rail, arrow buttons, or keyboard updates `currentIndex`; editing a slide title or content item mutates that slide in state so both the live preview and `.pptx` export reflect edits; selecting a theme updates `activeTheme` immediately; clicking export builds the `.pptx` file and displays an inline error notice if export fails.
- **Key Safeguards & Integrations**:
  - **Server-Only Credentials**: `GEMINI_API_KEY` stays strictly in server `process.env`, with `.env.example` documenting the variable name and zero keys bundled into browser assets.
  - **Input Validation & Clean Error Propagation**: Backend endpoints validate request fields and payload limits before calling Gemini, returning structured JSON error status codes without external third-party error webhooks.
  - **Safe Rendering**: All slide and user-entered text renders through standard React bindings without raw HTML injection or `window.alert` dialogs.
