export type LayoutType =
  | 'title'
  | 'split_left'
  | 'split_right'
  | 'minimal_typography'
  | 'timeline_flow'
  | 'comparison_grid'
  | 'editorial_spotlight';

export type Language = 'uz' | 'en' | 'ru';

export type VisualKind =
  | 'stat'
  | 'steps'
  | 'highlights'
  | 'quote'
  | 'timeline'
  | 'comparison';

export type VisualMotif =
  | 'orbital'
  | 'waves'
  | 'nodes'
  | 'peaks'
  | 'grid'
  | 'prism';

export interface SlideVisualItem {
  label: string;
  value: string;
}

export interface SlideVisual {
  kind: VisualKind;
  heading: string;
  items: SlideVisualItem[];
}

export interface Theme {
  id: string;
  name: string;
  isDark?: boolean;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
    textLight: string;
  };
  font: string;
}

export interface Slide {
  title: string;
  sectionTag?: string;
  content: string[];
  layout: LayoutType;
  visual?: SlideVisual;
  visualMotif?: VisualMotif;
  speakerNotes?: string;
  imageData?: string;
}

export interface UsageStats {
  model: string;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
}

export interface PresentationPlanResponse {
  themeId: string;
  slides: Slide[];
  usageStats: UsageStats;
}

export interface PresentationData {
  topic: string;
  themeId: string;
  slides: Slide[];
}

export enum AppStatus {
  IDLE = 'IDLE',
  GENERATING_PLAN = 'GENERATING_PLAN',
  READY = 'READY',
  ERROR = 'ERROR',
}

export interface GenerationProgress {
  current: number;
  total: number;
}

/* ------------------------------------------------------------------ */
/* Kurs ishi (course work) types                                        */
/* ------------------------------------------------------------------ */

export type AppMode = 'slides' | 'coursework';

export interface CourseMeta {
  ministry: string;
  university: string;
  faculty: string;
  subjectName: string;
  student: string;
  group: string;
  supervisor: string;
  city: string;
  year: string;
}

export interface CourseSettings {
  topic: string;
  pages: number;
  chapterCount: number;
  language: Language;
  additionalInfo?: string;
  meta: CourseMeta;
}

export interface CourseSection {
  title: string;
  keyPoints: string[];
  paragraphs: string[];
}

export interface CourseChapter {
  title: string;
  sections: CourseSection[];
}

export interface CourseIntro {
  relevance: string;
  goal: string;
  tasks: string[];
  object: string;
  subject: string;
  methods: string;
  structure: string;
}

export interface CourseWork {
  topic: string;
  language: Language;
  pages: number;
  meta: CourseMeta;
  intro: CourseIntro;
  chapters: CourseChapter[];
  conclusion: string[];
  references: string[];
}

export interface CourseOutline {
  title: string;
  chapters: {
    title: string;
    sections: { title: string; keyPoints: string[] }[];
  }[];
}

export interface CourseProgress {
  done: number;
  total: number;
  label: string;
}
