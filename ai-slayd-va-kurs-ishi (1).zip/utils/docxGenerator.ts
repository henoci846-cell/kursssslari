import {
  AlignmentType,
  Document,
  Footer,
  LevelFormat,
  Packer,
  Paragraph,
  PageNumber,
  TableOfContents,
  TextRun,
  HeadingLevel,
} from 'docx';
import type { CourseWork, Language } from '../types';

/* ------------------------------------------------------------------ */
/* Formatting constants (typical university requirements)              */
/* A4, margins L 30 mm / R 15 mm / T 20 mm / B 20 mm,                   */
/* Times New Roman 14 pt, 1.5 line spacing, first-line indent 1.25 cm   */
/* ------------------------------------------------------------------ */

const FONT = 'Times New Roman';
const SIZE = 28; // half-points -> 14 pt
const LINE = 360; // 1.5 spacing
const FIRST_LINE = 709; // 1.25 cm
const MM = 56.6929; // twips per millimetre

const PAGE = {
  size: { width: 11906, height: 16838 }, // A4 in twips
  margin: {
    top: Math.round(20 * MM),
    bottom: Math.round(20 * MM),
    left: Math.round(30 * MM),
    right: Math.round(15 * MM),
  },
};

interface Labels {
  courseWork: string;
  subject: string;
  topic: string;
  student: string;
  group: string;
  supervisor: string;
  contents: string;
  introduction: string;
  chapter: string;
  conclusion: string;
  references: string;
  relevance: string;
  goal: string;
  tasks: string;
  object: string;
  subjectOfStudy: string;
  methods: string;
  structure: string;
}

const LABELS: Record<Language, Labels> = {
  uz: {
    courseWork: 'KURS ISHI',
    subject: 'Fan:',
    topic: 'Mavzu:',
    student: 'Bajardi:',
    group: 'Guruh:',
    supervisor: 'Ilmiy rahbar:',
    contents: 'MUNDARIJA',
    introduction: 'KIRISH',
    chapter: 'BOB',
    conclusion: 'XULOSA',
    references: 'FOYDALANILGAN ADABIYOTLAR ROʻYXATI',
    relevance: 'Mavzuning dolzarbligi.',
    goal: 'Tadqiqotning maqsadi.',
    tasks: 'Tadqiqotning vazifalari:',
    object: 'Tadqiqotning obyekti.',
    subjectOfStudy: 'Tadqiqotning predmeti.',
    methods: 'Tadqiqot usullari.',
    structure: 'Kurs ishining tuzilishi.',
  },
  en: {
    courseWork: 'COURSE WORK',
    subject: 'Subject:',
    topic: 'Topic:',
    student: 'Prepared by:',
    group: 'Group:',
    supervisor: 'Supervisor:',
    contents: 'CONTENTS',
    introduction: 'INTRODUCTION',
    chapter: 'CHAPTER',
    conclusion: 'CONCLUSION',
    references: 'LIST OF REFERENCES',
    relevance: 'Relevance of the topic.',
    goal: 'Aim of the research.',
    tasks: 'Research objectives:',
    object: 'Object of the research.',
    subjectOfStudy: 'Subject of the research.',
    methods: 'Research methods.',
    structure: 'Structure of the paper.',
  },
  ru: {
    courseWork: 'КУРСОВАЯ РАБОТА',
    subject: 'Дисциплина:',
    topic: 'Тема:',
    student: 'Выполнил(а):',
    group: 'Группа:',
    supervisor: 'Научный руководитель:',
    contents: 'СОДЕРЖАНИЕ',
    introduction: 'ВВЕДЕНИЕ',
    chapter: 'ГЛАВА',
    conclusion: 'ЗАКЛЮЧЕНИЕ',
    references: 'СПИСОК ИСПОЛЬЗОВАННОЙ ЛИТЕРАТУРЫ',
    relevance: 'Актуальность темы.',
    goal: 'Цель исследования.',
    tasks: 'Задачи исследования:',
    object: 'Объект исследования.',
    subjectOfStudy: 'Предмет исследования.',
    methods: 'Методы исследования.',
    structure: 'Структура работы.',
  },
};

export const DEFAULT_MINISTRY: Record<Language, string> = {
  uz: 'OʻZBEKISTON RESPUBLIKASI OLIY TAʼLIM, FAN VA INNOVATSIYALAR VAZIRLIGI',
  en: 'MINISTRY OF HIGHER EDUCATION, SCIENCE AND INNOVATION OF THE REPUBLIC OF UZBEKISTAN',
  ru: 'МИНИСТЕРСТВО ВЫСШЕГО ОБРАЗОВАНИЯ, НАУКИ И ИННОВАЦИЙ РЕСПУБЛИКИ УЗБЕКИСТАН',
};

const toRoman = (n: number): string => {
  const map: [number, string][] = [
    [10, 'X'],
    [9, 'IX'],
    [5, 'V'],
    [4, 'IV'],
    [1, 'I'],
  ];
  let value = n;
  let out = '';
  for (const [num, sym] of map) {
    while (value >= num) {
      out += sym;
      value -= num;
    }
  }
  return out;
};

/* ------------------------------------------------------------------ */
/* Paragraph builders                                                   */
/* ------------------------------------------------------------------ */

const body = (text: string): Paragraph =>
  new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    indent: { firstLine: FIRST_LINE },
    spacing: { line: LINE, before: 0, after: 0 },
    children: [new TextRun({ text, font: FONT, size: SIZE })],
  });

const labelled = (label: string, text: string): Paragraph =>
  new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    indent: { firstLine: FIRST_LINE },
    spacing: { line: LINE, before: 0, after: 0 },
    children: [
      new TextRun({ text: `${label} `, font: FONT, size: SIZE, bold: true }),
      new TextRun({ text, font: FONT, size: SIZE }),
    ],
  });

const bodyParagraphs = (text: string): Paragraph[] =>
  text
    .split(/\n+/)
    .map((t) => t.trim())
    .filter(Boolean)
    .map(body);

const centered = (
  text: string,
  opts: { bold?: boolean; size?: number; before?: number; after?: number; allCaps?: boolean } = {}
): Paragraph =>
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { line: 276, before: opts.before ?? 0, after: opts.after ?? 0 },
    children: [
      new TextRun({
        text,
        font: FONT,
        size: opts.size ?? SIZE,
        bold: opts.bold ?? false,
        allCaps: opts.allCaps ?? false,
      }),
    ],
  });

const chapterHeading = (text: string, pageBreak = true): Paragraph =>
  new Paragraph({
    heading: HeadingLevel.HEADING_1,
    pageBreakBefore: pageBreak,
    children: [new TextRun({ text, font: FONT, size: SIZE, bold: true })],
  });

const sectionHeading = (text: string): Paragraph =>
  new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, font: FONT, size: SIZE, bold: true })],
  });

const infoLine = (label: string, value: string): Paragraph =>
  new Paragraph({
    indent: { left: 4536 },
    spacing: { line: 276, before: 0, after: 160 },
    children: [
      new TextRun({ text: `${label} `, font: FONT, size: SIZE, bold: true }),
      new TextRun({ text: value.trim() || '______________________', font: FONT, size: SIZE }),
    ],
  });

/* ------------------------------------------------------------------ */
/* Document                                                             */
/* ------------------------------------------------------------------ */

export const buildCourseworkDocument = (work: CourseWork): Document => {
  const L = LABELS[work.language] ?? LABELS.uz;
  const { meta } = work;
  const ministry = meta.ministry.trim() || DEFAULT_MINISTRY[work.language];

  /* ---- Title page ---- */
  const titlePage: Paragraph[] = [
    centered(ministry, { bold: true, after: 240 }),
  ];
  if (meta.university.trim()) {
    titlePage.push(centered(meta.university.trim(), { bold: true, after: 120 }));
  }
  if (meta.faculty.trim()) {
    titlePage.push(centered(meta.faculty.trim(), { after: 120 }));
  }
  titlePage.push(
    centered(L.courseWork, { bold: true, size: 40, before: 2400, after: 480 }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { line: 276, before: 0, after: 120 },
      children: [
        new TextRun({ text: `${L.subject} `, font: FONT, size: SIZE, bold: true }),
        new TextRun({ text: meta.subjectName.trim() || '______________________', font: FONT, size: SIZE }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { line: 276, before: 0, after: 1600 },
      children: [
        new TextRun({ text: `${L.topic} `, font: FONT, size: SIZE, bold: true }),
        new TextRun({ text: `“${work.topic}”`, font: FONT, size: SIZE }),
      ],
    }),
    infoLine(L.student, meta.student),
    infoLine(L.group, meta.group),
    infoLine(L.supervisor, meta.supervisor),
    centered(
      [meta.city.trim(), meta.year.trim()].filter(Boolean).join(' – '),
      { bold: true, before: 2600 }
    )
  );

  /* ---- Contents ---- */
  const contents: (Paragraph | TableOfContents)[] = [
    centered(L.contents, { bold: true, after: 240 }),
    new TableOfContents(L.contents, {
      hyperlink: true,
      headingStyleRange: '1-2',
    }),
  ];

  /* ---- Introduction ---- */
  const intro = work.intro;
  const introParas: Paragraph[] = [chapterHeading(L.introduction)];
  if (intro.relevance.trim()) {
    const [first, ...rest] = intro.relevance.split(/\n+/).map((t) => t.trim()).filter(Boolean);
    if (first) introParas.push(labelled(L.relevance, first));
    rest.forEach((t) => introParas.push(body(t)));
  }
  if (intro.goal.trim()) introParas.push(labelled(L.goal, intro.goal.trim()));
  if (intro.tasks.length > 0) {
    introParas.push(labelled(L.tasks, ''));
    intro.tasks.forEach((task) =>
      introParas.push(
        new Paragraph({
          numbering: { reference: 'tasks', level: 0 },
          alignment: AlignmentType.JUSTIFIED,
          spacing: { line: LINE, before: 0, after: 0 },
          children: [new TextRun({ text: task.replace(/[.;]\s*$/, ''), font: FONT, size: SIZE })],
        })
      )
    );
  }
  if (intro.object.trim()) introParas.push(labelled(L.object, intro.object.trim()));
  if (intro.subject.trim()) introParas.push(labelled(L.subjectOfStudy, intro.subject.trim()));
  if (intro.methods.trim()) introParas.push(labelled(L.methods, intro.methods.trim()));
  if (intro.structure.trim()) introParas.push(labelled(L.structure, intro.structure.trim()));

  /* ---- Chapters ---- */
  const chapterParas: Paragraph[] = [];
  work.chapters.forEach((chapter, ci) => {
    chapterParas.push(chapterHeading(`${toRoman(ci + 1)} ${L.chapter}. ${chapter.title}`));
    chapter.sections.forEach((section, si) => {
      chapterParas.push(sectionHeading(`${ci + 1}.${si + 1}. ${section.title}`));
      section.paragraphs.forEach((p) => chapterParas.push(...bodyParagraphs(p)));
    });
  });

  /* ---- Conclusion ---- */
  const conclusionParas: Paragraph[] = [chapterHeading(L.conclusion)];
  work.conclusion.forEach((p) => conclusionParas.push(...bodyParagraphs(p)));

  /* ---- References ---- */
  const referenceParas: Paragraph[] = [chapterHeading(L.references)];
  work.references.forEach((ref) =>
    referenceParas.push(
      new Paragraph({
        numbering: { reference: 'references', level: 0 },
        alignment: AlignmentType.JUSTIFIED,
        spacing: { line: LINE, before: 0, after: 0 },
        children: [new TextRun({ text: ref, font: FONT, size: SIZE })],
      })
    )
  );

  const footer = new Footer({
    children: [
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 24 }),
        ],
      }),
    ],
  });

  return new Document({
    creator: meta.student.trim() || 'Kurs ishi',
    title: work.topic,
    features: { updateFields: true },
    styles: {
      default: {
        document: {
          run: { font: FONT, size: SIZE },
          paragraph: { spacing: { line: LINE, before: 0, after: 0 } },
        },
      },
      paragraphStyles: [
        {
          id: 'Heading1',
          name: 'Heading 1',
          basedOn: 'Normal',
          next: 'Normal',
          quickFormat: true,
          run: { font: FONT, size: SIZE, bold: true, allCaps: true, color: '000000' },
          paragraph: {
            alignment: AlignmentType.CENTER,
            spacing: { line: LINE, before: 0, after: 240 },
            keepNext: true,
            keepLines: true,
            outlineLevel: 0,
          },
        },
        {
          id: 'Heading2',
          name: 'Heading 2',
          basedOn: 'Normal',
          next: 'Normal',
          quickFormat: true,
          run: { font: FONT, size: SIZE, bold: true, color: '000000' },
          paragraph: {
            alignment: AlignmentType.LEFT,
            indent: { firstLine: FIRST_LINE },
            spacing: { line: LINE, before: 240, after: 120 },
            keepNext: true,
            keepLines: true,
            outlineLevel: 1,
          },
        },
        {
          id: 'TOC1',
          name: 'toc 1',
          basedOn: 'Normal',
          next: 'Normal',
          run: { font: FONT, size: SIZE, bold: true },
          paragraph: { spacing: { line: 300, before: 0, after: 80 } },
        },
        {
          id: 'TOC2',
          name: 'toc 2',
          basedOn: 'Normal',
          next: 'Normal',
          run: { font: FONT, size: SIZE },
          paragraph: { indent: { left: 284 }, spacing: { line: 300, before: 0, after: 60 } },
        },
      ],
    },
    numbering: {
      config: [
        {
          reference: 'tasks',
          levels: [
            {
              level: 0,
              format: LevelFormat.DECIMAL,
              text: '%1)',
              alignment: AlignmentType.LEFT,
              style: {
                paragraph: { indent: { left: 1134, hanging: 425 } },
                run: { font: FONT, size: SIZE },
              },
            },
          ],
        },
        {
          reference: 'references',
          levels: [
            {
              level: 0,
              format: LevelFormat.DECIMAL,
              text: '%1.',
              alignment: AlignmentType.LEFT,
              style: {
                paragraph: { indent: { left: 709, hanging: 709 } },
                run: { font: FONT, size: SIZE },
              },
            },
          ],
        },
      ],
    },
    sections: [
      {
        properties: { page: PAGE },
        children: titlePage,
      },
      {
        properties: { page: { ...PAGE, pageNumbers: { start: 2 } } },
        footers: { default: footer },
        children: [
          ...contents,
          ...introParas,
          ...chapterParas,
          ...conclusionParas,
          ...referenceParas,
        ],
      },
    ],
  });
};

const safeFileName = (text: string): string =>
  text
    .replace(/[\\/:*?"<>|]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'kurs-ishi';

export const courseworkToBlob = async (work: CourseWork): Promise<Blob> =>
  Packer.toBlob(buildCourseworkDocument(work));

export const downloadCourseworkDocx = async (work: CourseWork): Promise<void> => {
  const blob = await courseworkToBlob(work);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${safeFileName(work.topic)}.docx`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 2000);
};
