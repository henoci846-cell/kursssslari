import pptxgen from 'pptxgenjs';
import { Slide, Theme } from '../types';
import { resolveTheme } from './themes';

export const generatePPTX = async (
  topic: string,
  slides: Slide[],
  themeInput?: Theme | null
) => {
  const theme = resolveTheme(themeInput);
  const pres = new pptxgen();

  pres.title = topic;
  pres.layout = 'LAYOUT_16x9';

  const c = (hex: string) => hex.replace('#', '');
  const cleanContent = (text: string) => text.replace(/^\d+[\s.)-]+\s*/, '');
  const cardBg = theme.isDark ? '1E293B' : 'FFFFFF';
  const cardBorder = c(theme.colors.accent);

  pres.defineSlideMaster({
    title: 'MASTER_SLIDE',
    background: { color: c(theme.colors.background) },
    objects: [
      {
        rect: {
          x: 0.5,
          y: 0.2,
          w: 0.8,
          h: 0.05,
          fill: { color: c(theme.colors.accent) },
        },
      },
    ],
    slideNumber: {
      x: 9.2,
      y: 5.25,
      w: 0.6,
      h: 0.3,
      align: 'right',
      color: c(theme.colors.textLight),
      fontSize: 9,
    },
  });

  for (const slide of slides) {
    const pptxSlide = pres.addSlide({ masterName: 'MASTER_SLIDE' });

    if (slide.speakerNotes) {
      pptxSlide.addNotes(slide.speakerNotes);
    }

    if (slide.layout === 'title') {
      pptxSlide.addShape(pres.ShapeType.rect, {
        x: 1.0,
        y: 1.0,
        w: 8.0,
        h: 3.6,
        fill: { color: cardBg, transparency: theme.isDark ? 15 : 10 },
        line: { color: c(theme.colors.primary), width: 1.2, transparency: 50 },
        rectRadius: 0.3,
      });

      if (slide.sectionTag) {
        pptxSlide.addText(slide.sectionTag, {
          x: 1.4,
          y: 1.18,
          w: 7.2,
          h: 0.3,
          fontSize: 10,
          color: c(theme.colors.accent),
          bold: true,
          align: 'center',
          fontFace: 'Arial',
        });
      }

      pptxSlide.addText(slide.title, {
        x: 1.4,
        y: 1.5,
        w: 7.2,
        h: 1.2,
        fontSize: 34,
        color: c(theme.colors.primary),
        bold: true,
        align: 'center',
        valign: 'middle',
        fontFace: 'Arial',
      });

      pptxSlide.addShape(pres.ShapeType.line, {
        x: 4.25,
        y: 2.85,
        w: 1.5,
        h: 0,
        line: { color: c(theme.colors.accent), width: 3 },
      });

      pptxSlide.addText(cleanContent(slide.content[0] || ''), {
        x: 1.4,
        y: 3.1,
        w: 7.2,
        h: 0.9,
        fontSize: 18,
        color: c(theme.colors.text),
        align: 'center',
        valign: 'top',
        fontFace: 'Arial',
      });
      continue;
    }

    if (slide.layout === 'minimal_typography' && !slide.imageData) {
      if (slide.sectionTag) {
        pptxSlide.addText(slide.sectionTag, {
          x: 1.2,
          y: 0.95,
          w: 7.6,
          h: 0.35,
          fontSize: 11,
          color: c(theme.colors.accent),
          bold: true,
          align: 'center',
          fontFace: 'Arial',
        });
      }

      pptxSlide.addText(slide.title, {
        x: 1.0,
        y: 1.4,
        w: 8.0,
        h: 1.2,
        fontSize: 30,
        color: c(theme.colors.primary),
        bold: true,
        align: 'center',
        valign: 'middle',
        fontFace: 'Arial',
      });

      pptxSlide.addShape(pres.ShapeType.line, {
        x: 4.3,
        y: 2.75,
        w: 1.4,
        h: 0,
        line: { color: c(theme.colors.accent), width: 2 },
      });

      pptxSlide.addText(slide.content.map(cleanContent).join(' '), {
        x: 1.2,
        y: 3.0,
        w: 7.6,
        h: 1.6,
        fontSize: 17,
        color: c(theme.colors.text),
        align: 'center',
        valign: 'top',
        fontFace: 'Arial',
      });
      continue;
    }

    const hasRightPanel =
      Boolean(slide.imageData) ||
      Boolean(slide.visual && slide.visual.items && slide.visual.items.length > 0);
    const mediaFirst = slide.layout === 'split_right';
    const contentW = hasRightPanel ? 5.2 : 9.0;
    const textBoxX = mediaFirst && hasRightPanel ? 4.35 : 0.4;
    const visualBoxX = mediaFirst ? 0.4 : 5.95;

    pptxSlide.addShape(pres.ShapeType.rect, {
      x: textBoxX,
      y: 0.4,
      w: contentW + 0.2,
      h: 4.75,
      fill: { color: cardBg, transparency: theme.isDark ? 15 : 10 },
      line: { color: cardBorder, width: 1, transparency: 65 },
      rectRadius: 0.25,
    });

    if (slide.sectionTag) {
      pptxSlide.addText(slide.sectionTag, {
        x: textBoxX + 0.25,
        y: 0.5,
        w: contentW - 0.3,
        h: 0.25,
        fontSize: 9.5,
        color: c(theme.colors.accent),
        bold: true,
        fontFace: 'Arial',
      });
    }

    pptxSlide.addText(slide.title, {
      x: textBoxX + 0.25,
      y: slide.sectionTag ? 0.78 : 0.55,
      w: contentW - 0.3,
      h: 0.85,
      fontSize: 21,
      color: c(theme.colors.secondary),
      bold: true,
      fontFace: 'Arial',
      valign: 'top',
    });

    const startY = 1.72;
    const isList =
      slide.content.length > 2 ||
      (slide.content.length > 1 && slide.content.every((cItem) => cItem.length < 75));

    if (isList) {
      const columnCount = !hasRightPanel && slide.content.length > 5 ? 2 : 1;
      slide.content.forEach((point, i) => {
        const col = i % columnCount;
        const row = Math.floor(i / columnCount);
        const colW = columnCount === 1 ? contentW - 0.5 : contentW / 2 - 0.4;

        pptxSlide.addText(`${i + 1}. ${cleanContent(point)}`, {
          x: textBoxX + 0.3 + col * (colW + 0.25),
          y: startY + row * 0.62,
          w: colW,
          h: 0.55,
          fontSize: 14,
          color: c(theme.colors.text),
          fontFace: 'Arial',
          valign: 'top',
        });
      });
    } else {
      const fullText = slide.content.map((item) => cleanContent(item)).join('\n\n');
      pptxSlide.addText(fullText, {
        x: textBoxX + 0.3,
        y: startY,
        w: contentW - 0.4,
        h: 3.25,
        fontSize: 15.5,
        color: c(theme.colors.text),
        fontFace: 'Arial',
        valign: 'top',
        align: 'left',
      });
    }

    if (slide.imageData) {
      pptxSlide.addShape(pres.ShapeType.rect, {
        x: visualBoxX,
        y: 0.55,
        w: 3.65,
        h: 4.4,
        fill: { color: cardBg, transparency: 15 },
        line: { color: c(theme.colors.primary), width: 2 },
        rectRadius: 0.25,
      });

      pptxSlide.addImage({
        data: slide.imageData,
        x: visualBoxX + 0.1,
        y: 0.65,
        w: 3.45,
        h: 4.2,
        sizing: { type: 'cover', w: 3.45, h: 4.2 },
      });
    } else if (slide.visual && slide.visual.items && slide.visual.items.length > 0) {
      pptxSlide.addShape(pres.ShapeType.rect, {
        x: visualBoxX,
        y: 0.4,
        w: 3.65,
        h: 4.75,
        fill: { color: cardBg, transparency: theme.isDark ? 10 : 5 },
        line: { color: c(theme.colors.accent), width: 1, transparency: 55 },
        rectRadius: 0.25,
      });

      pptxSlide.addText(slide.visual.heading.toUpperCase(), {
        x: visualBoxX + 0.2,
        y: 0.58,
        w: 3.25,
        h: 0.42,
        fontSize: 11,
        bold: true,
        color: c(theme.colors.secondary),
        fontFace: 'Arial',
      });

      slide.visual.items.slice(0, 4).forEach((item, idx) => {
        const yPos = 1.12 + idx * 0.94;
        pptxSlide.addShape(pres.ShapeType.rect, {
          x: visualBoxX + 0.2,
          y: yPos,
          w: 3.25,
          h: 0.82,
          fill: { color: theme.isDark ? '0F172A' : 'F8FAFC' },
          line: { color: c(theme.colors.accent), width: 0.75, transparency: 65 },
          rectRadius: 0.15,
        });

        pptxSlide.addText(item.label, {
          x: visualBoxX + 0.33,
          y: yPos + 0.06,
          w: 3.0,
          h: 0.25,
          fontSize: 10,
          bold: true,
          color: c(theme.colors.accent),
          fontFace: 'Arial',
        });

        pptxSlide.addText(item.value, {
          x: visualBoxX + 0.33,
          y: yPos + 0.3,
          w: 3.0,
          h: 0.46,
          fontSize: 11,
          color: c(theme.colors.text),
          fontFace: 'Arial',
          valign: 'top',
        });
      });
    }
  }

  const safeTopic = topic
    .replace(/[^a-z0-9а-яА-Я\s-]/gi, '')
    .trim()
    .replace(/\s+/g, '_')
    .substring(0, 30);
  const fileName = `${safeTopic || 'taqdimot'}.pptx`;

  await pres.writeFile({ fileName });
};
