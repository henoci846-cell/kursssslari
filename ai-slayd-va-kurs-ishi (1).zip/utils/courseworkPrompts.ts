import type { CourseOutline, Language } from '../types.ts';

const getLanguageName = (lang: Language): string => {
  switch (lang) {
    case 'uz':
      return "O'zbek (Latin script)";
    case 'en':
      return 'English';
    case 'ru':
      return 'Русский';
    default:
      return "O'zbek (Latin script)";
  }
};

const languageRules = (lang: Language): string => {
  if (lang === 'uz') {
    return `Write in natural, grammatically flawless, literary-standard Uzbek using the modern Latin alphabet.
   - Spell the letters oʻ and gʻ with the modifier letter ʻ (U+02BB), e.g. "oʻqish", "togʻri", "Oʻzbekiston", "gʻoya".
   - Use the tutuq belgisi ʼ (U+02BC) in words such as "maʼno", "taʼlim", "maʼlumot", "iqtisodiy jihatdan baʼzi".
   - Never use a plain apostrophe ' or a backtick in place of these letters.
   - Check word endings, suffix harmony, case endings and punctuation carefully. Do not mix in Cyrillic or Russian words; use established Uzbek terminology (use an international term only when it is the normal term in the field).`;
  }
  if (lang === 'ru') {
    return `Write in natural, grammatically flawless, literary Russian. Check spelling, case agreement and punctuation carefully.`;
  }
  return `Write in natural, grammatically flawless, formal academic English. Check spelling, agreement and punctuation carefully.`;
};

export const SYSTEM_INSTRUCTION_COURSE = (language: Language): string => {
  const langName = getLanguageName(language);
  return `You are an experienced university professor and academic writer who prepares course papers (kurs ishi) for university students.

OUTPUT LANGUAGE: ${langName}.
1. LANGUAGE QUALITY (CRITICAL): ${languageRules(language)}
2. ACADEMIC STYLE: formal, impersonal, logically connected. Use precise terminology, definitions, classifications, causes and effects, comparisons and concrete examples. Each paragraph carries one idea and is roughly 70-130 words. Do not use first-person singular. Avoid filler, clichés and empty phrases.
3. FACTUAL ACCURACY (CRITICAL): Never invent statistics, percentages, dates, laws, article numbers, quotations, authors, research studies or institutions. State only facts that are well established. If an exact figure is uncertain, describe the matter qualitatively instead. Do not add in-text citation markers such as [1].
4. PLAIN TEXT ONLY: No markdown, no asterisks, no hashtags, no bullet characters, no numbered lists inside paragraphs, no emojis, no placeholders such as [insert here], no meta-comments about the task, and do not repeat the section title as the first line.
5. NO REPETITION: Stay strictly inside the scope of the requested part and do not repeat what other parts of the paper already cover.
6. COMPLETENESS: Every sentence must be finished. Never cut a paragraph off.`;
};

const describeOutline = (outline: CourseOutline): string =>
  outline.chapters
    .map((chapter, ci) => {
      const sections = chapter.sections
        .map(
          (section, si) =>
            `   ${ci + 1}.${si + 1}. ${section.title}${
              section.keyPoints.length ? ` (key points: ${section.keyPoints.join('; ')})` : ''
            }`
        )
        .join('\n');
      return `Chapter ${ci + 1}: ${chapter.title}\n${sections}`;
    })
    .join('\n');

export const createCourseOutlinePrompt = (
  topic: string,
  pages: number,
  chapterCount: number,
  sectionsPerChapter: number,
  language: Language,
  additionalInfo?: string
): string => {
  const langName = getLanguageName(language);
  let prompt = `Course paper topic: "${topic}".
Target length: about ${pages} A4 pages.
Output language: ${langName}.
Create the structure (outline) of this course paper.`;

  if (additionalInfo && additionalInfo.trim()) {
    prompt += `\nStudent's extra instructions: "${additionalInfo.trim()}".`;
  }

  prompt += `

STRICT REQUIREMENTS:
1. Return EXACTLY ${chapterCount} chapters and EXACTLY ${sectionsPerChapter} sections in every chapter.
2. Logical progression: chapter 1 = theoretical foundations and key concepts; middle chapter(s) = analysis, methods, current state, practice; last chapter = practical application, problems, solutions and prospects (adapt sensibly to the topic).
3. Titles must be specific to the topic, concise (max ~12 words), written as noun phrases without a trailing period, without numbering and without the words "Chapter" or "Bob".
4. For every section give 3-4 short 'keyPoints' (3-8 words each) that say exactly what that section covers, so that sections do not overlap.
5. The 'title' field is the final, polished title of the course paper (same topic, properly capitalised, no quotation marks).
6. Write everything in ${langName} with correct spelling.`;
  return prompt;
};

export type CoursePartKind = 'intro' | 'section' | 'conclusion' | 'references';

export interface CoursePartArgs {
  kind: CoursePartKind;
  topic: string;
  subject: string;
  language: Language;
  outline: CourseOutline;
  chapterIndex?: number;
  sectionIndex?: number;
  targetWords?: number;
  existing?: string[];
  additionalInfo?: string;
}

export const createCoursePartPrompt = (args: CoursePartArgs): string => {
  const {
    kind,
    topic,
    subject,
    language,
    outline,
    chapterIndex = 0,
    sectionIndex = 0,
    targetWords = 500,
    existing = [],
    additionalInfo,
  } = args;
  const langName = getLanguageName(language);

  let prompt = `Course paper topic: "${topic}".${subject ? `\nAcademic subject / field: "${subject}".` : ''}
Output language: ${langName}.
${additionalInfo && additionalInfo.trim() ? `Student's extra instructions: "${additionalInfo.trim()}".\n` : ''}
FULL STRUCTURE OF THE PAPER (for context and to avoid overlap):
${describeOutline(outline)}
`;

  if (kind === 'intro') {
    prompt += `
TASK: Write the INTRODUCTION (kirish) of the course paper as structured fields:
- relevance: why the topic is important and timely (1-2 paragraphs worth, ~170-220 words, written as flowing text; you may separate two paragraphs with a blank line).
- goal: one precise sentence stating the aim of the research.
- tasks: 4-5 research tasks, each a short complete phrase in a consistent grammatical form, without numbering.
- object: one sentence naming the object of the research.
- subject: one sentence naming the subject of the research (narrower than the object).
- methods: one or two sentences listing the methods used (e.g. literature analysis, comparison, systematization, generalization) that fit the topic.
- structure: 2-3 sentences describing the structure: introduction, ${outline.chapters.length} chapters (briefly say what each chapter covers), conclusion and the list of references.
Do not include field names inside the values.`;
  } else if (kind === 'section') {
    const chapter = outline.chapters[chapterIndex];
    const section = chapter?.sections[sectionIndex];
    prompt += `
TASK: Write the full text of section ${chapterIndex + 1}.${sectionIndex + 1} "${section?.title ?? ''}" (chapter "${chapter?.title ?? ''}").
Cover exactly these key points: ${section?.keyPoints.join('; ') ?? ''}.
Length: about ${targetWords} words in total, as ${Math.max(2, Math.round(targetWords / 110))} paragraphs of roughly 90-130 words each.`;
    if (existing.length > 0) {
      prompt += `

The section already contains the following paragraphs. Do NOT repeat or rephrase them. Write ONLY NEW, additional paragraphs that deepen the section (new aspects, examples, analysis) and flow naturally after the existing text:
${existing.map((p, i) => `(${i + 1}) ${p}`).join('\n')}`;
    }
  } else if (kind === 'conclusion') {
    prompt += `
TASK: Write the CONCLUSION (xulosa) of the course paper. About ${targetWords} words in 3-4 paragraphs. Summarise the main findings of each chapter in order, show that the aim and tasks were achieved and give 2-3 sensible practical recommendations or prospects. Do not introduce new facts and do not use lists.`;
  } else {
    prompt += `
TASK: Compile the LIST OF REFERENCES (foydalanilgan adabiyotlar) for this topic: 12-16 entries.

ABSOLUTE RULES (the student will submit this list):
1. Include ONLY sources you are highly confident really exist: official laws and normative documents of the Republic of Uzbekistan (with their real official titles), well-known textbooks, monographs and reference works by real authors with their real titles, and official web portals given only as a top-level domain (for example lex.uz, stat.uz, president.uz, edu.uz) or a well-known international organisation website.
2. NEVER invent authors, titles, publishers, page numbers, DOIs, article URLs or years. If you are not sure about the year or publisher, omit that element rather than guess. If you cannot reach 12 entries with confident sources, return fewer.
3. Order: normative-legal acts first, then books and articles alphabetically by the author's surname, then internet resources last.
4. Use the standard bibliographic style of Uzbek universities (Author A.A. Title. – City: Publisher, Year. – pages), in ${langName} or in the original language of the source (Uzbek, Russian or English).
5. Entries must not contain numbering; return each entry as its own string.`;
  }
  return prompt;
};
