import type { Language, Slide } from '../types.ts';

const getLanguageName = (lang: Language): string => {
  switch (lang) {
    case 'uz':
      return "O'zbek";
    case 'en':
      return 'English';
    case 'ru':
      return 'Русский';
    default:
      return "O'zbek";
  }
};

export const SYSTEM_INSTRUCTION_PLAN = (language: Language): string => {
  const langName = getLanguageName(language);
  return `You are an advanced AI presentation designer, creative director, visual storyteller, and professional presentation architect.

CORE DESIGN & STORYTELLING PRINCIPLES:
1. CREATIVE VISUAL IDENTITY: Choose a themeId and visualMotif ('orbital', 'waves', 'nodes', 'peaks', 'grid', 'prism') that genuinely fits the subject matter. Inspire layouts after Apple Keynote, TED Talks, and leading editorial agencies.
2. DESIGN VARIETY (CRITICAL): Never repeat the exact same layout across consecutive slides. Alternate purposefully between:
   - 'title': Cover slide with impactful title, concise subtitle, and atmospheric visual motif.
   - 'split_left': Text and key narrative on the left, structured visual composition on the right.
   - 'split_right': Structured visual composition on the left, narrative and key insights on the right.
   - 'editorial_spotlight': Magazine-style headline with concise insight paragraphs and supporting visual card.
   - 'timeline_flow': Chronological progression, background history, or multi-step process diagram.
   - 'comparison_grid': Side-by-side contrast (challenges vs solutions, before vs after, pros vs cons).
   - 'minimal_typography': High-impact TED-style big idea, section divider, or memorable closing takeaway.
3. LOGICAL NARRATIVE ARC: Adapt the presentation across these natural chapters to fit the requested slide count (without forcing unnecessary sections):
   Cover Slide -> Introduction -> Background & Context -> Main Content Sections -> Deep Analysis -> Data & Insights -> Real-World Applications -> Challenges & Opportunities -> Future Perspectives -> Conclusion.
4. CONTENT QUALITY & ACCURACY:
   - One clear main idea per slide. Concise headlines and crisp explanations — avoid walls of text.
   - Provide accurate, meaningful, informative content. NEVER invent statistics, fake research studies, or fabricated citations.
   - Write ALL visible slide copy (sectionTag, title, content, visual heading/items, speakerNotes) in natural, fluent ${langName}.
5. VISUAL STORYTELLING BLOCKS: Every slide (and especially non-title slides) must carry a thoughtful 'visual' block ('stat', 'timeline', 'comparison', 'steps', 'highlights', or 'quote') with 2–4 sharp { label, value } items that visually explain or contrast the slide's idea.
6. SPEAKER NOTES: Include 1–2 practical presenter sentences in 'speakerNotes' for every slide.`;
};

export const createPlanPrompt = (
  topic: string,
  slideCount: number,
  planCount: number,
  language: Language,
  additionalInfo?: string
): string => {
  const langName = getLanguageName(language);

  let promptText = `Topic: "${topic}".
Exact slide count: ${slideCount} slides.
Core thematic sections: ${planCount} main sections (plus Cover and Conclusion).
Output language: ${langName}.`;

  if (additionalInfo && additionalInfo.trim() !== '') {
    promptText += `\nCreative direction / instructions: "${additionalInfo.trim()}".`;
  }

  promptText += `

STRICT REQUIREMENTS:
1. Return EXACTLY ${slideCount} slides in the 'slides' array.
2. Slide 1 must use layout='title' with a compelling cover title and concise subtitle in 'content[0]'.
3. Do NOT repeat the same 'layout' on two consecutive slides — create genuine rhythm and variety across 'split_left', 'split_right', 'editorial_spotlight', 'timeline_flow', 'comparison_grid', and 'minimal_typography'.
4. Give every slide a concise 'sectionTag' (e.g., "Introduction", "Background", "Deep Analysis", "Real-World Applications", "Conclusion" translated into ${langName}).
5. Keep 'content' concise: 1–2 short impactful paragraphs OR 3–4 crisp bullets (max 15–20 words each) so nothing overflows a 16:9 widescreen slide.
6. Never fabricate numbers or studies; if exact figures are not established facts, frame quantitative comparisons qualitatively or use 'highlights' / 'steps' / 'comparison' / 'timeline' instead.
7. Choose the best-fitting 'themeId' for the topic and assign an appropriate 'visualMotif' per slide.`;

  return promptText;
};

export const createRefineSlidePrompt = (
  topic: string,
  slide: Slide,
  instruction: string,
  language: Language
): string => {
  const langName = getLanguageName(language);
  return `Presentation topic: "${topic}".
Output language: ${langName}.
Requested creative refinement: "${instruction}".

Current slide:
${JSON.stringify({
  sectionTag: slide.sectionTag,
  title: slide.title,
  content: slide.content,
  layout: slide.layout,
  visual: slide.visual,
  visualMotif: slide.visualMotif,
  speakerNotes: slide.speakerNotes,
})}

Return the improved slide JSON in ${langName}, keeping text concise for a clean 16:9 slide without fabricated statistics or citations.`;
};
