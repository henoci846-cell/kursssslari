import React, { useEffect, useState } from 'react';
import { AlertCircle, Download, Info, Loader2, RefreshCw, RotateCcw } from 'lucide-react';
import type { CourseIntro, CourseWork, Language } from '../types';
import { translations } from '../utils/translations';
import {
  countCourseWorkWords,
  countWords,
  estimatePages,
  normalizeCourseWork,
  normalizeUzbek,
  regenerateCoursePart,
  regenerateCourseSection,
} from '../services/courseworkService';
import { downloadCourseworkDocx } from '../utils/docxGenerator';

interface CourseworkViewerProps {
  work: CourseWork;
  onWorkChange: (work: CourseWork) => void;
  onRestart: () => void;
  language: Language;
}

const fieldClass =
  'w-full px-4 py-3 rounded-xl border bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none transition-all text-sm leading-relaxed';

/** Textarea that keeps local text while typing and commits on blur. */
const CommitTextarea: React.FC<{
  value: string;
  onCommit: (value: string) => void;
  rows?: number;
  invalid?: boolean;
  ariaLabel?: string;
}> = ({ value, onCommit, rows = 6, invalid, ariaLabel }) => {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <textarea
      aria-label={ariaLabel}
      value={text}
      rows={rows}
      onChange={(e) => setText(e.target.value)}
      onBlur={() => {
        if (text !== value) onCommit(text);
      }}
      className={`${fieldClass} ${invalid ? 'border-red-300 bg-red-50/40' : 'border-slate-300'}`}
    />
  );
};

const CommitInput: React.FC<{
  value: string;
  onCommit: (value: string) => void;
  className?: string;
  ariaLabel?: string;
}> = ({ value, onCommit, className = '', ariaLabel }) => {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <input
      type="text"
      aria-label={ariaLabel}
      value={text}
      onChange={(e) => setText(e.target.value)}
      onBlur={() => {
        if (text !== value) onCommit(text);
      }}
      className={`${fieldClass} border-slate-300 ${className}`}
    />
  );
};

const RegenButton: React.FC<{
  busy: boolean;
  onClick: () => void;
  label: string;
  busyLabel: string;
}> = ({ busy, onClick, label, busyLabel }) => (
  <button
    type="button"
    onClick={onClick}
    disabled={busy}
    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60 disabled:cursor-not-allowed transition-colors cursor-pointer whitespace-nowrap shrink-0"
  >
    {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
    <span>{busy ? busyLabel : label}</span>
  </button>
);

const Card: React.FC<{ title: string; action?: React.ReactNode; children: React.ReactNode }> = ({
  title,
  action,
  children,
}) => (
  <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 md:p-6">
    <div className="flex items-center justify-between gap-3 mb-4">
      <h2 className="font-display text-base md:text-lg font-bold text-slate-900">{title}</h2>
      {action}
    </div>
    {children}
  </section>
);

const Label: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="block text-xs font-semibold text-slate-600 mb-1.5">{children}</span>
);

const splitLines = (text: string): string[] =>
  text
    .split(/\n+/)
    .map((l) => l.trim())
    .filter(Boolean);

const roman = ['I', 'II', 'III', 'IV', 'V', 'VI'];

export const CourseworkViewer: React.FC<CourseworkViewerProps> = ({
  work,
  onWorkChange,
  onRestart,
  language,
}) => {
  const t = translations[language];
  const [busy, setBusy] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const norm = (text: string) => (work.language === 'uz' ? normalizeUzbek(text.trim()) : text.trim());
  const paragraphsOf = (text: string) => text.split(/\n\s*\n|\n/).map(norm).filter(Boolean);

  const update = (patch: Partial<CourseWork>) => onWorkChange({ ...work, ...patch });

  const updateIntro = (patch: Partial<CourseIntro>) => update({ intro: { ...work.intro, ...patch } });

  const updateSection = (ci: number, si: number, patch: Partial<CourseWork['chapters'][0]['sections'][0]>) =>
    update({
      chapters: work.chapters.map((c, i) =>
        i !== ci
          ? c
          : { ...c, sections: c.sections.map((s, j) => (j !== si ? s : { ...s, ...patch })) }
      ),
    });

  const hasEmptySection = work.chapters.some((c) => c.sections.some((s) => s.paragraphs.length === 0));
  const introEmpty = !work.intro.relevance.trim();
  const conclusionEmpty = work.conclusion.length === 0;
  const hasEmpty = hasEmptySection || introEmpty || conclusionEmpty;

  const run = async (key: string, task: () => Promise<void>) => {
    setBusy(key);
    setError(null);
    try {
      await task();
    } catch (err) {
      setError(err instanceof Error ? err.message : t.errorTitle);
    } finally {
      setBusy(null);
    }
  };

  const handleRegenSection = (ci: number, si: number) =>
    run(`s-${ci}-${si}`, async () => {
      const paragraphs = await regenerateCourseSection(work, ci, si);
      updateSection(ci, si, { paragraphs });
    });

  const handleRegenPart = (kind: 'intro' | 'conclusion' | 'references') =>
    run(kind, async () => {
      const patch = await regenerateCoursePart(work, kind);
      onWorkChange(normalizeCourseWork({ ...work, ...patch }));
    });

  const handleDownload = async () => {
    setIsDownloading(true);
    setError(null);
    try {
      await downloadCourseworkDocx(work);
    } catch (err) {
      console.error(err);
      setError(t.cwExportError);
    } finally {
      setIsDownloading(false);
    }
  };

  const words = countCourseWorkWords(work);
  const estimate = t.cwEstimate.replace('{pages}', String(estimatePages(work))).replace('{words}', String(words));

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col gap-4">
      <div className="sticky top-[61px] z-30 flex flex-wrap items-center justify-between gap-3 bg-white/95 backdrop-blur border border-slate-200 rounded-2xl shadow-sm px-4 py-3">
        <button
          type="button"
          onClick={onRestart}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{t.btnRestart}</span>
        </button>
        <span className="text-sm text-slate-600 tabular-nums">{estimate}</span>
        <button
          type="button"
          onClick={handleDownload}
          disabled={isDownloading}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-indigo-600 text-white text-sm font-semibold hover:bg-indigo-700 disabled:opacity-60 transition-colors cursor-pointer whitespace-nowrap"
        >
          {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
          <span>{isDownloading ? t.cwBtnDownloading : t.cwBtnDownload}</span>
        </button>
      </div>

      {error && (
        <div role="alert" className="flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {hasEmpty && (
        <div role="status" className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{t.cwWarnEmpty}</span>
        </div>
      )}
      <div className="flex items-start gap-2 rounded-xl border border-indigo-100 bg-indigo-50/60 px-4 py-3 text-sm text-indigo-900">
        <Info className="w-4 h-4 mt-0.5 shrink-0" />
        <div className="space-y-1">
          <p>{t.cwEditHint}</p>
          <p>{t.cwTocNote}</p>
        </div>
      </div>

      <Card title={t.cwSecTitlePage}>
        <Label>{t.cwTopicField}</Label>
        <CommitInput
          ariaLabel={t.cwTopicField}
          value={work.topic}
          onCommit={(v) => update({ topic: norm(v) })}
        />
      </Card>

      <Card
        title={t.cwSecIntro}
        action={
          <RegenButton
            busy={busy === 'intro'}
            onClick={() => handleRegenPart('intro')}
            label={t.cwRegenerate}
            busyLabel={t.cwRegenerating}
          />
        }
      >
        <div className="space-y-4">
          <div>
            <Label>{t.cwRelevance}</Label>
            <CommitTextarea
              ariaLabel={t.cwRelevance}
              rows={8}
              invalid={introEmpty}
              value={work.intro.relevance}
              onCommit={(v) => updateIntro({ relevance: norm(v) })}
            />
          </div>
          <div>
            <Label>{t.cwGoal}</Label>
            <CommitTextarea ariaLabel={t.cwGoal} rows={2} value={work.intro.goal} onCommit={(v) => updateIntro({ goal: norm(v) })} />
          </div>
          <div>
            <Label>{t.cwTasks}</Label>
            <CommitTextarea
              ariaLabel={t.cwTasks}
              rows={5}
              value={work.intro.tasks.join('\n')}
              onCommit={(v) => updateIntro({ tasks: splitLines(v).map(norm) })}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>{t.cwObject}</Label>
              <CommitTextarea ariaLabel={t.cwObject} rows={3} value={work.intro.object} onCommit={(v) => updateIntro({ object: norm(v) })} />
            </div>
            <div>
              <Label>{t.cwSubjectOfStudy}</Label>
              <CommitTextarea ariaLabel={t.cwSubjectOfStudy} rows={3} value={work.intro.subject} onCommit={(v) => updateIntro({ subject: norm(v) })} />
            </div>
          </div>
          <div>
            <Label>{t.cwMethods}</Label>
            <CommitTextarea ariaLabel={t.cwMethods} rows={3} value={work.intro.methods} onCommit={(v) => updateIntro({ methods: norm(v) })} />
          </div>
          <div>
            <Label>{t.cwStructure}</Label>
            <CommitTextarea ariaLabel={t.cwStructure} rows={4} value={work.intro.structure} onCommit={(v) => updateIntro({ structure: norm(v) })} />
          </div>
        </div>
      </Card>

      {work.chapters.map((chapter, ci) => (
        <Card key={ci} title={`${roman[ci] ?? ci + 1} ${t.cwChapter}`}>
          <div className="mb-5">
            <CommitInput
              ariaLabel={`${roman[ci] ?? ci + 1} ${t.cwChapter}`}
              className="font-semibold"
              value={chapter.title}
              onCommit={(v) =>
                update({ chapters: work.chapters.map((c, i) => (i === ci ? { ...c, title: norm(v) } : c)) })
              }
            />
          </div>
          <div className="space-y-6">
            {chapter.sections.map((section, si) => {
              const key = `s-${ci}-${si}`;
              const empty = section.paragraphs.length === 0;
              const sectionWords = section.paragraphs.reduce((sum, p) => sum + countWords(p), 0);
              return (
                <div key={si}>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-sm font-bold text-slate-500 tabular-nums shrink-0">
                      {ci + 1}.{si + 1}.
                    </span>
                    <CommitInput
                      ariaLabel={`${ci + 1}.${si + 1}`}
                      className="font-semibold !py-2"
                      value={section.title}
                      onCommit={(v) => updateSection(ci, si, { title: norm(v) })}
                    />
                    <RegenButton
                      busy={busy === key}
                      onClick={() => handleRegenSection(ci, si)}
                      label={t.cwRegenerate}
                      busyLabel={t.cwRegenerating}
                    />
                  </div>
                  {empty && <p className="text-xs text-red-700 mb-1.5">{t.cwEmptySection}</p>}
                  <CommitTextarea
                    ariaLabel={`${ci + 1}.${si + 1}`}
                    rows={10}
                    invalid={empty}
                    value={section.paragraphs.join('\n\n')}
                    onCommit={(v) => updateSection(ci, si, { paragraphs: paragraphsOf(v) })}
                  />
                  <p className="mt-1 text-xs text-slate-500 tabular-nums">
                    {sectionWords} {t.cwWordsShort}
                  </p>
                </div>
              );
            })}
          </div>
        </Card>
      ))}

      <Card
        title={t.cwSecConclusion}
        action={
          <RegenButton
            busy={busy === 'conclusion'}
            onClick={() => handleRegenPart('conclusion')}
            label={t.cwRegenerate}
            busyLabel={t.cwRegenerating}
          />
        }
      >
        <CommitTextarea
          ariaLabel={t.cwSecConclusion}
          rows={8}
          invalid={conclusionEmpty}
          value={work.conclusion.join('\n\n')}
          onCommit={(v) => update({ conclusion: paragraphsOf(v) })}
        />
      </Card>

      <Card
        title={t.cwSecReferences}
        action={
          <RegenButton
            busy={busy === 'references'}
            onClick={() => handleRegenPart('references')}
            label={t.cwRegenerate}
            busyLabel={t.cwRegenerating}
          />
        }
      >
        <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs text-amber-900 mb-3">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{t.cwReferencesWarning}</span>
        </div>
        <Label>{t.cwReferencesHint}</Label>
        <CommitTextarea
          ariaLabel={t.cwSecReferences}
          rows={10}
          value={work.references.join('\n')}
          onCommit={(v) => update({ references: splitLines(v).map(norm) })}
        />
      </Card>
    </div>
  );
};
