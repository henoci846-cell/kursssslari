import React, { useState, useEffect, useRef } from 'react';
import { Slide, Theme, Language, SlideVisual, VisualMotif } from '../types';
import {
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Download,
  Loader2,
  Palette,
  ImagePlus,
  Trash2,
  Wand2,
  Sparkles,
  Plus,
  X,
  AlertCircle,
  BarChart3,
  ListChecks,
  Quote,
  Lightbulb,
  GitCommitHorizontal,
  Columns2,
} from 'lucide-react';
import { generatePPTX } from '../utils/pptxGenerator';
import { refineSlideContent } from '../services/geminiService';
import { THEMES, getTheme, resolveTheme } from '../utils/themes';
import { translations } from '../utils/translations';

interface SlideViewerProps {
  slides: Slide[];
  onSlidesChange: (slides: Slide[]) => void;
  topic: string;
  theme?: Theme | null;
  onThemeChange?: (theme: Theme) => void;
  onRestart: () => void;
  language: Language;
}

export const SlideViewer: React.FC<SlideViewerProps> = ({
  slides,
  onSlidesChange,
  topic,
  theme: initialTheme,
  onThemeChange,
  onRestart,
  language,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [activeTheme, setActiveTheme] = useState<Theme>(() =>
    resolveTheme(initialTheme)
  );
  const [isDownloading, setIsDownloading] = useState(false);
  const [isPolishing, setIsPolishing] = useState<'concise' | 'visual' | null>(null);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const sidebarThumbRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const carouselThumbRefs = useRef<(HTMLButtonElement | null)[]>([]);

  const t = translations[language];

  useEffect(() => {
    setActiveTheme(resolveTheme(initialTheme));
  }, [initialTheme]);

  useEffect(() => {
    if (currentIndex >= slides.length && slides.length > 0) {
      setCurrentIndex(slides.length - 1);
    }
  }, [slides.length, currentIndex]);

  useEffect(() => {
    const scrollOptions: ScrollIntoViewOptions = {
      block: 'nearest',
      inline: 'nearest',
      behavior: 'smooth',
    };
    sidebarThumbRefs.current[currentIndex]?.scrollIntoView(scrollOptions);
    carouselThumbRefs.current[currentIndex]?.scrollIntoView(scrollOptions);
  }, [currentIndex]);

  const currentSlide = slides[currentIndex];
  const isFirst = currentIndex === 0;
  const isLast = currentIndex === slides.length - 1;

  const nextSlide = () => {
    if (!isLast) setCurrentIndex((prev) => prev + 1);
  };
  const prevSlide = () => {
    if (!isFirst) setCurrentIndex((prev) => prev - 1);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isEditingText =
        target?.tagName === 'INPUT' ||
        target?.tagName === 'TEXTAREA' ||
        target?.isContentEditable;
      if (isEditingText) return;

      if (e.key === 'ArrowRight') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, isLast, isFirst]);

  if (!currentSlide) return null;

  const cleanContent = (text: string) => text.replace(/^\d+[\s.)-]+\s*/, '');

  const updateCurrentSlide = (patch: Partial<Slide>) => {
    const updated = slides.map((s, idx) =>
      idx === currentIndex ? { ...s, ...patch } : s
    );
    onSlidesChange(updated);
  };

  const handleTitleChange = (value: string) => {
    updateCurrentSlide({ title: value });
  };

  const handleContentItemChange = (itemIndex: number, value: string) => {
    const nextContent = currentSlide.content.map((item, idx) =>
      idx === itemIndex ? value : item
    );
    updateCurrentSlide({ content: nextContent });
  };

  const handleAddContentItem = () => {
    updateCurrentSlide({ content: [...currentSlide.content, ''] });
  };

  const handleRemoveContentItem = (itemIndex: number) => {
    if (currentSlide.content.length <= 1) return;
    updateCurrentSlide({
      content: currentSlide.content.filter((_, idx) => idx !== itemIndex),
    });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const allowedTypes = new Set(['image/png', 'image/jpeg', 'image/webp']);
    if (!allowedTypes.has(file.type)) {
      setActionError('Please upload a PNG, JPEG, or WebP image.');
      e.target.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setActionError(null);
        updateCurrentSlide({ imageData: reader.result });
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handlePolishSlide = async (mode: 'concise' | 'visual') => {
    const targetIndex = currentIndex;
    const targetSlide = slides[targetIndex];
    if (!targetSlide) return;

    setIsPolishing(mode);
    setActionError(null);
    const instruction =
      mode === 'concise'
        ? 'Make the slide content sharper, more concise, and punchier while keeping accurate facts.'
        : 'Redesign this slide with a fresh layout, a more compelling visual diagram or comparison/timeline structure, and an updated visualMotif that best illustrates the slide title and content.';

    try {
      const updated = await refineSlideContent(
        topic,
        targetSlide,
        instruction,
        language
      );
      const nextSlides = slides.map((s, idx) =>
        idx === targetIndex
          ? { ...updated, imageData: s.imageData ?? updated.imageData }
          : s
      );
      onSlidesChange(nextSlides);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : t.errorTitle);
    } finally {
      setIsPolishing(null);
    }
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    setActionError(null);
    try {
      await generatePPTX(topic, slides, activeTheme);
    } catch (error) {
      console.error(error);
      setActionError(t.exportError);
    } finally {
      setIsDownloading(false);
    }
  };

  const isDark = Boolean(activeTheme.isDark);
  const cardSurfaceClass = isDark
    ? 'bg-slate-900/75 border-white/15'
    : 'bg-white/88 border-slate-200/80';
  const secondarySurfaceClass = isDark
    ? 'bg-slate-800/75 border-white/12'
    : 'bg-slate-50/95 border-slate-200/80';

  const getVisualIcon = (kind: SlideVisual['kind']) => {
    switch (kind) {
      case 'stat':
        return (
          <BarChart3
            className="w-4 h-4 shrink-0"
            style={{ color: activeTheme.colors.accent }}
          />
        );
      case 'steps':
        return (
          <ListChecks
            className="w-4 h-4 shrink-0"
            style={{ color: activeTheme.colors.accent }}
          />
        );
      case 'timeline':
        return (
          <GitCommitHorizontal
            className="w-4 h-4 shrink-0"
            style={{ color: activeTheme.colors.accent }}
          />
        );
      case 'comparison':
        return (
          <Columns2
            className="w-4 h-4 shrink-0"
            style={{ color: activeTheme.colors.accent }}
          />
        );
      case 'quote':
        return (
          <Quote
            className="w-4 h-4 shrink-0"
            style={{ color: activeTheme.colors.accent }}
          />
        );
      default:
        return (
          <Lightbulb
            className="w-4 h-4 shrink-0"
            style={{ color: activeTheme.colors.accent }}
          />
        );
    }
  };

  const renderMotifBackdrop = (motif: VisualMotif = 'orbital') => {
    const strokePrimary = activeTheme.colors.primary;
    const strokeAccent = activeTheme.colors.accent;

    return (
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none overflow-hidden opacity-[0.14]"
      >
        {motif === 'orbital' && (
          <svg
            viewBox="0 0 800 450"
            className="w-full h-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <circle cx="660" cy="120" r="190" fill="none" stroke={strokeAccent} strokeWidth="1.5" />
            <circle cx="660" cy="120" r="130" fill="none" stroke={strokePrimary} strokeWidth="1" strokeDasharray="6 6" />
            <circle cx="130" cy="370" r="140" fill="none" stroke={strokePrimary} strokeWidth="1.2" />
          </svg>
        )}
        {motif === 'waves' && (
          <svg
            viewBox="0 0 800 450"
            className="w-full h-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <path d="M0 330 Q 200 250 400 320 T 800 280" fill="none" stroke={strokeAccent} strokeWidth="2" />
            <path d="M0 370 Q 220 290 430 360 T 800 320" fill="none" stroke={strokePrimary} strokeWidth="1.5" />
            <path d="M0 410 Q 240 340 460 395 T 800 365" fill="none" stroke={strokeAccent} strokeWidth="1" />
          </svg>
        )}
        {motif === 'nodes' && (
          <svg
            viewBox="0 0 800 450"
            className="w-full h-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <line x1="560" y1="80" x2="700" y2="160" stroke={strokeAccent} strokeWidth="1.5" />
            <line x1="700" y1="160" x2="620" y2="310" stroke={strokePrimary} strokeWidth="1.5" />
            <line x1="620" y1="310" x2="740" y2="380" stroke={strokeAccent} strokeWidth="1.5" />
            <circle cx="560" cy="80" r="8" fill={strokeAccent} />
            <circle cx="700" cy="160" r="11" fill={strokePrimary} />
            <circle cx="620" cy="310" r="7" fill={strokeAccent} />
            <circle cx="740" cy="380" r="9" fill={strokePrimary} />
          </svg>
        )}
        {motif === 'peaks' && (
          <svg
            viewBox="0 0 800 450"
            className="w-full h-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <polygon points="480,450 620,210 760,450" fill="none" stroke={strokePrimary} strokeWidth="1.5" />
            <polygon points="580,450 710,160 840,450" fill="none" stroke={strokeAccent} strokeWidth="1.5" />
          </svg>
        )}
        {motif === 'grid' && (
          <svg
            viewBox="0 0 800 450"
            className="w-full h-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <line x1="120" y1="0" x2="120" y2="450" stroke={strokePrimary} strokeWidth="1" />
            <line x1="400" y1="0" x2="400" y2="450" stroke={strokePrimary} strokeWidth="0.75" />
            <line x1="680" y1="0" x2="680" y2="450" stroke={strokeAccent} strokeWidth="1" />
            <line x1="0" y1="90" x2="800" y2="90" stroke={strokePrimary} strokeWidth="0.75" />
            <line x1="0" y1="360" x2="800" y2="360" stroke={strokeAccent} strokeWidth="1" />
          </svg>
        )}
        {motif === 'prism' && (
          <svg
            viewBox="0 0 800 450"
            className="w-full h-full"
            preserveAspectRatio="xMidYMid slice"
          >
            <polygon points="620,60 760,225 620,390 480,225" fill="none" stroke={strokeAccent} strokeWidth="1.5" />
            <polygon points="620,110 710,225 620,340 530,225" fill="none" stroke={strokePrimary} strokeWidth="1" />
          </svg>
        )}
      </div>
    );
  };

  const renderVisualPanel = (visual?: SlideVisual) => {
    if (!visual || !visual.items || visual.items.length === 0) return null;

    return (
      <div
        className={`h-full rounded-2xl border p-5 md:p-6 flex flex-col justify-center ${secondarySurfaceClass}`}
      >
        <div className="flex items-center gap-2 mb-4">
          {getVisualIcon(visual.kind)}
          <h3
            className="text-xs md:text-sm font-bold tracking-wide"
            style={{ color: activeTheme.colors.secondary }}
          >
            {visual.heading}
          </h3>
        </div>

        {visual.kind === 'comparison' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {visual.items.slice(0, 4).map((item, idx) => (
              <div
                key={idx}
                className={`rounded-xl border p-3 ${
                  isDark
                    ? 'bg-slate-900/65 border-white/10'
                    : 'bg-white border-slate-200/75'
                }`}
              >
                <div
                  className="text-[11px] font-bold mb-1"
                  style={{ color: activeTheme.colors.accent }}
                >
                  {item.label}
                </div>
                <div
                  className="text-xs font-medium leading-snug"
                  style={{ color: activeTheme.colors.text }}
                >
                  {item.value}
                </div>
              </div>
            ))}
          </div>
        ) : visual.kind === 'timeline' || visual.kind === 'steps' ? (
          <div className="space-y-2.5">
            {visual.items.slice(0, 4).map((item, idx) => (
              <div
                key={idx}
                className={`rounded-xl border px-3.5 py-2.5 flex items-start gap-3 ${
                  isDark
                    ? 'bg-slate-900/65 border-white/10'
                    : 'bg-white border-slate-200/75'
                }`}
              >
                <span
                  className="font-mono tabular-nums text-[11px] font-bold mt-0.5 shrink-0"
                  style={{ color: activeTheme.colors.accent }}
                >
                  {String(idx + 1).padStart(2, '0')}
                </span>
                <div>
                  <div
                    className="text-xs font-semibold mb-0.5"
                    style={{ color: activeTheme.colors.secondary }}
                  >
                    {item.label}
                  </div>
                  <div
                    className="text-xs leading-snug opacity-90"
                    style={{ color: activeTheme.colors.text }}
                  >
                    {item.value}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {visual.items.slice(0, 4).map((item, idx) => (
              <div
                key={idx}
                className={`rounded-xl border px-3.5 py-2.5 ${
                  isDark
                    ? 'bg-slate-900/65 border-white/10'
                    : 'bg-white border-slate-200/75'
                }`}
              >
                <div
                  className="text-xs font-semibold mb-0.5"
                  style={{ color: activeTheme.colors.accent }}
                >
                  {item.label}
                </div>
                <div
                  className="text-xs md:text-sm font-medium leading-snug"
                  style={{ color: activeTheme.colors.text }}
                >
                  {item.value}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  const renderSectionMeta = () =>
    currentSlide.sectionTag ? (
      <div
        className="text-[11px] font-semibold tracking-wide mb-2 opacity-75"
        style={{ color: activeTheme.colors.accent }}
      >
        {currentSlide.sectionTag}
      </div>
    ) : null;

  const renderEditableBody = (compact = false) => {
    const styleTitle = { color: activeTheme.colors.secondary };
    const styleText = { color: activeTheme.colors.text };
    const styleBullet = {
      backgroundColor: activeTheme.colors.primary,
      color: isDark ? activeTheme.colors.background : '#ffffff',
    };
    const isList =
      currentSlide.content.length > 2 ||
      (currentSlide.content.length > 1 &&
        currentSlide.content.every((c) => c.length < 75));

    return (
      <>
        {renderSectionMeta()}
        <input
          type="text"
          value={currentSlide.title}
          onChange={(e) => handleTitleChange(e.target.value)}
          aria-label="Slide title"
          className={`w-full bg-transparent font-display font-bold mb-3 outline-none focus:ring-2 focus:ring-indigo-500/30 rounded-lg px-1.5 py-1 ${
            compact ? 'text-lg md:text-xl' : 'text-lg md:text-2xl'
          }`}
          style={styleTitle}
        />

        <div className="space-y-2">
          {currentSlide.content.map((item, idx) => (
            <div key={idx} className="group flex items-start gap-2.5">
              {isList && (
                <span
                  className="mt-1.5 w-5 h-5 rounded-md flex items-center justify-center shrink-0 text-[11px] font-bold tabular-nums"
                  style={styleBullet}
                >
                  {idx + 1}
                </span>
              )}
              <textarea
                value={cleanContent(item)}
                onChange={(e) => handleContentItemChange(idx, e.target.value)}
                rows={isList ? 2 : 3}
                aria-label={`Slide content ${idx + 1}`}
                className="flex-1 bg-transparent text-sm md:text-[15px] leading-relaxed font-medium outline-none resize-none focus:ring-2 focus:ring-indigo-500/30 rounded-lg px-1.5 py-1"
                style={styleText}
              />
              {currentSlide.content.length > 1 && (
                <button
                  type="button"
                  onClick={() => handleRemoveContentItem(idx)}
                  title={t.removeBullet}
                  className="opacity-0 group-hover:opacity-100 focus:opacity-100 p-1 rounded text-slate-400 hover:text-red-500 transition-opacity cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={handleAddContentItem}
          className="mt-2.5 self-start inline-flex items-center gap-1 text-xs font-semibold opacity-70 hover:opacity-100 transition-opacity cursor-pointer"
          style={{ color: activeTheme.colors.accent }}
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t.addBullet}</span>
        </button>
      </>
    );
  };

  const renderSlideStageContent = () => {
    const styleText = { color: activeTheme.colors.text };

    if (currentSlide.layout === 'title') {
      return (
        <div className="h-full flex flex-col items-center justify-center text-center p-8 md:p-14 relative">
          <div
            className={`relative z-10 p-8 md:p-12 rounded-3xl border shadow-sm w-full max-w-3xl ${cardSurfaceClass}`}
          >
            {renderSectionMeta()}
            <textarea
              value={currentSlide.title}
              onChange={(e) => handleTitleChange(e.target.value)}
              rows={2}
              aria-label="Slide title"
              className="w-full bg-transparent text-center font-display text-2xl md:text-5xl font-extrabold leading-tight outline-none resize-none focus:ring-2 focus:ring-indigo-500/30 rounded-lg px-2 py-1"
              style={{ color: activeTheme.colors.primary }}
            />
            <div
              className="h-1 w-20 mx-auto my-5 rounded-full"
              style={{ backgroundColor: activeTheme.colors.accent }}
            />
            <textarea
              value={cleanContent(currentSlide.content[0] || '')}
              onChange={(e) => handleContentItemChange(0, e.target.value)}
              rows={2}
              aria-label="Slide subtitle"
              className="w-full bg-transparent text-center text-base md:text-xl font-medium opacity-90 outline-none resize-none focus:ring-2 focus:ring-indigo-500/30 rounded-lg px-2 py-1"
              style={styleText}
            />
          </div>
        </div>
      );
    }

    if (currentSlide.layout === 'minimal_typography' && !currentSlide.imageData) {
      return (
        <div className="h-full flex flex-col items-center justify-center text-center p-8 md:p-14 relative overflow-y-auto md:overflow-hidden">
          <div className="max-w-3xl w-full space-y-5">
            {renderSectionMeta()}
            <textarea
              value={currentSlide.title}
              onChange={(e) => handleTitleChange(e.target.value)}
              rows={2}
              aria-label="Slide title"
              className="w-full bg-transparent text-center font-display text-2xl md:text-4xl font-extrabold leading-tight outline-none resize-none focus:ring-2 focus:ring-indigo-500/30 rounded-lg px-2 py-1"
              style={{ color: activeTheme.colors.primary }}
            />
            <div
              className="h-px w-24 mx-auto"
              style={{ backgroundColor: activeTheme.colors.accent }}
            />
            <textarea
              value={cleanContent(currentSlide.content.join(' '))}
              onChange={(e) => handleContentItemChange(0, e.target.value)}
              rows={3}
              aria-label="Slide statement"
              className="w-full bg-transparent text-center text-base md:text-xl leading-relaxed font-medium opacity-90 outline-none resize-none focus:ring-2 focus:ring-indigo-500/30 rounded-lg px-2 py-1"
              style={styleText}
            />
            {currentSlide.visual?.items?.[0] && (
              <div
                className={`inline-block mx-auto rounded-xl border px-5 py-3 text-left ${secondarySurfaceClass}`}
              >
                <div
                  className="text-xs font-bold mb-0.5"
                  style={{ color: activeTheme.colors.accent }}
                >
                  {currentSlide.visual.items[0].label}
                </div>
                <div
                  className="text-sm font-medium"
                  style={{ color: activeTheme.colors.text }}
                >
                  {currentSlide.visual.items[0].value}
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }

    if (
      (currentSlide.layout === 'timeline_flow' ||
        currentSlide.layout === 'comparison_grid') &&
      !currentSlide.imageData
    ) {
      return (
        <div className="h-full flex flex-col p-6 md:p-9 gap-4 overflow-y-auto md:overflow-hidden">
          <div className={`rounded-2xl border px-5 py-4 ${cardSurfaceClass}`}>
            {renderEditableBody(true)}
          </div>
          {currentSlide.visual && (
            <div className="flex-1 min-h-0">
              {renderVisualPanel(currentSlide.visual)}
            </div>
          )}
        </div>
      );
    }

    const hasRightPanel =
      Boolean(currentSlide.imageData) ||
      Boolean(currentSlide.visual && currentSlide.visual.items?.length > 0);
    const mediaFirst = currentSlide.layout === 'split_right';

    return (
      <div className="h-full flex flex-col md:flex-row p-6 md:p-9 gap-5 items-stretch overflow-y-auto md:overflow-hidden">
        <div
          className={`flex flex-col justify-center rounded-2xl border p-5 md:p-6 ${cardSurfaceClass} ${
            hasRightPanel ? 'w-full md:flex-[1.2]' : 'w-full'
          } ${mediaFirst ? 'md:order-2' : 'md:order-1'}`}
        >
          {renderEditableBody()}
        </div>

        {hasRightPanel && (
          <div
            className={`w-full md:flex-1 flex flex-col justify-center min-h-[190px] ${
              mediaFirst ? 'md:order-1' : 'md:order-2'
            }`}
          >
            {currentSlide.imageData ? (
              <div className="relative w-full h-56 md:h-full rounded-2xl overflow-hidden border border-slate-200/60 shadow-sm">
                <img
                  src={currentSlide.imageData}
                  alt={currentSlide.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            ) : (
              renderVisualPanel(currentSlide.visual)
            )}
          </div>
        )}
      </div>
    );
  };

  const renderSlideThumbnail = (slide: Slide) => {
    const hasVisual =
      Boolean(slide.imageData) ||
      Boolean(slide.visual && slide.visual.items && slide.visual.items.length > 0);
    const thumbCardBg = isDark ? 'rgba(15, 23, 42, 0.78)' : 'rgba(255, 255, 255, 0.9)';
    const thumbBorder = isDark ? 'rgba(255, 255, 255, 0.14)' : 'rgba(226, 232, 240, 0.9)';
    const mediaFirst = slide.layout === 'split_right';

    return (
      <div
        className="w-full aspect-video rounded-lg overflow-hidden border p-1.5 flex flex-col justify-center select-none pointer-events-none"
        style={{
          backgroundColor: activeTheme.colors.background,
          borderColor: thumbBorder,
          fontFamily: activeTheme.font,
        }}
      >
        {slide.layout === 'title' || slide.layout === 'minimal_typography' ? (
          <div
            className="w-full h-full rounded-md border px-2 py-1 flex flex-col items-center justify-center text-center"
            style={{ backgroundColor: thumbCardBg, borderColor: thumbBorder }}
          >
            <div
              className="text-[7px] font-bold leading-tight line-clamp-2"
              style={{ color: activeTheme.colors.primary }}
            >
              {slide.title}
            </div>
            <div
              className="w-4 h-[1.5px] rounded-full my-1"
              style={{ backgroundColor: activeTheme.colors.accent }}
            />
            <div
              className="text-[5px] leading-tight line-clamp-1 opacity-80"
              style={{ color: activeTheme.colors.text }}
            >
              {cleanContent(slide.content[0] || '')}
            </div>
          </div>
        ) : (
          <div className="w-full h-full flex gap-1">
            <div
              className={`h-full rounded-md border p-1 flex flex-col justify-start overflow-hidden ${
                hasVisual ? 'w-[58%]' : 'w-full'
              } ${mediaFirst ? 'order-2' : 'order-1'}`}
              style={{ backgroundColor: thumbCardBg, borderColor: thumbBorder }}
            >
              <div
                className="text-[6.5px] font-bold leading-tight line-clamp-2 mb-1"
                style={{ color: activeTheme.colors.secondary }}
              >
                {slide.title}
              </div>
              <div className="space-y-0.5 overflow-hidden">
                {slide.content.slice(0, 3).map((line, lineIdx) => (
                  <div
                    key={lineIdx}
                    className="text-[4.8px] leading-tight line-clamp-1 opacity-85"
                    style={{ color: activeTheme.colors.text }}
                  >
                    {cleanContent(line)}
                  </div>
                ))}
              </div>
            </div>

            {hasVisual && (
              <div
                className={`w-[42%] h-full rounded-md border overflow-hidden flex flex-col justify-center ${
                  mediaFirst ? 'order-1' : 'order-2'
                }`}
                style={{ backgroundColor: thumbCardBg, borderColor: thumbBorder }}
              >
                {slide.imageData ? (
                  <img
                    src={slide.imageData}
                    alt=""
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="p-1 space-y-0.5">
                    <div
                      className="text-[4.5px] font-bold uppercase truncate"
                      style={{ color: activeTheme.colors.accent }}
                    >
                      {slide.visual?.heading}
                    </div>
                    {slide.visual?.items.slice(0, 2).map((item, i) => (
                      <div
                        key={i}
                        className="rounded px-1 py-0.5"
                        style={{
                          backgroundColor: isDark
                            ? 'rgba(30, 41, 59, 0.7)'
                            : 'rgba(241, 245, 249, 0.9)',
                        }}
                      >
                        <div
                          className="text-[4px] font-semibold truncate"
                          style={{ color: activeTheme.colors.accent }}
                        >
                          {item.label}
                        </div>
                        <div
                          className="text-[4px] truncate"
                          style={{ color: activeTheme.colors.text }}
                        >
                          {item.value}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-full max-w-7xl mx-auto flex flex-col gap-4">
      {/* Studio Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm">
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={onRestart}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.btnRestart}</span>
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={handleImageUpload}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ImagePlus className="w-3.5 h-3.5" />
            <span>{t.uploadImage}</span>
          </button>

          {currentSlide.imageData && (
            <button
              type="button"
              onClick={() => updateCurrentSlide({ imageData: undefined })}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-200 text-red-700 hover:bg-red-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.removeImage}</span>
            </button>
          )}

          <button
            type="button"
            disabled={isPolishing !== null}
            onClick={() => handlePolishSlide('concise')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 disabled:opacity-50 cursor-pointer"
          >
            {isPolishing === 'concise' ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Wand2 className="w-3.5 h-3.5 text-indigo-600" />
            )}
            <span>
              {isPolishing === 'concise' ? t.aiPolishLoading : t.aiPolishConcise}
            </span>
          </button>

          <button
            type="button"
            disabled={isPolishing !== null}
            onClick={() => handlePolishSlide('visual')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 disabled:opacity-50 cursor-pointer"
          >
            {isPolishing === 'visual' ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
            )}
            <span>
              {isPolishing === 'visual' ? t.aiPolishLoading : t.aiPolishVisual}
            </span>
          </button>
        </div>

        <div className="flex items-center gap-3">
          <span className="hidden xl:inline text-xs text-slate-500">
            {t.editHint}
          </span>

          <button
            type="button"
            onClick={handleDownload}
            disabled={isDownloading}
            className="inline-flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg text-xs font-semibold hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0 disabled:opacity-70 cursor-pointer"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>{t.btnDownloading}</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>{t.btnDownload}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {actionError && (
        <div className="flex items-center justify-between gap-3 bg-red-50 border border-red-200 text-red-800 px-4 py-2.5 rounded-xl text-xs font-medium">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{actionError}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionError(null)}
            className="text-red-600 hover:text-red-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Studio Grid: Thumbnail Sidebar + Slide Canvas */}
      <div className="grid grid-cols-1 lg:grid-cols-[260px_1fr] gap-4 items-start">
        <aside
          aria-label={t.slideOutline}
          className="bg-white border border-slate-200 rounded-xl p-3 max-h-[600px] overflow-y-auto hidden lg:block"
        >
          <div className="flex items-center justify-between text-xs font-semibold text-slate-500 px-1.5 pb-2.5 mb-2.5 border-b border-slate-100">
            <span>{t.slideOutline}</span>
            <span className="font-mono tabular-nums text-[11px] text-slate-400">
              {currentIndex + 1}/{slides.length}
            </span>
          </div>
          <div className="space-y-2.5">
            {slides.map((s, idx) => {
              const active = idx === currentIndex;
              return (
                <button
                  key={idx}
                  ref={(el) => {
                    sidebarThumbRefs.current[idx] = el;
                  }}
                  type="button"
                  onClick={() => setCurrentIndex(idx)}
                  aria-current={active ? 'step' : undefined}
                  className={`w-full text-left p-2 rounded-xl border transition-all cursor-pointer group ${
                    active
                      ? 'bg-indigo-50/70 border-indigo-600 ring-1 ring-indigo-600'
                      : 'bg-slate-50/50 border-slate-200/80 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {renderSlideThumbnail(s)}
                  <div className="mt-2 flex items-start gap-1.5 px-0.5">
                    <span
                      className={`font-mono tabular-nums text-[11px] font-semibold shrink-0 ${
                        active ? 'text-indigo-700' : 'text-slate-400'
                      }`}
                    >
                      {String(idx + 1).padStart(2, '0')}
                    </span>
                    <span
                      className={`text-xs line-clamp-1 leading-snug ${
                        active
                          ? 'text-indigo-900 font-semibold'
                          : 'text-slate-700 font-medium'
                      }`}
                    >
                      {s.title}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        <div className="flex flex-col gap-4">
          {/* 16:9 Slide Stage */}
          <div className="relative w-full md:aspect-video min-h-[480px] md:min-h-0 rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div
              className="absolute inset-0 transition-colors duration-300"
              style={{
                fontFamily: activeTheme.font,
                backgroundColor: activeTheme.colors.background,
              }}
            >
              {renderMotifBackdrop(currentSlide.visualMotif)}
              <div className="relative z-10 h-full w-full">
                {renderSlideStageContent()}
              </div>
              <div
                className={`absolute bottom-3 right-5 text-xs font-semibold tabular-nums z-20 px-2.5 py-1 rounded-md border ${
                  isDark
                    ? 'bg-slate-900/80 border-white/15'
                    : 'bg-white/85 border-slate-200/80'
                }`}
                style={{ color: activeTheme.colors.textLight }}
              >
                {currentIndex + 1} / {slides.length}
              </div>
            </div>
          </div>

          {/* Mobile / Tablet Bottom Thumbnail Carousel */}
          <div
            aria-label={t.slideOutline}
            className="lg:hidden bg-white border border-slate-200 rounded-xl p-2.5 overflow-x-auto"
          >
            <div className="flex items-stretch gap-2.5 min-w-max">
              {slides.map((s, idx) => {
                const active = idx === currentIndex;
                return (
                  <button
                    key={idx}
                    ref={(el) => {
                      carouselThumbRefs.current[idx] = el;
                    }}
                    type="button"
                    onClick={() => setCurrentIndex(idx)}
                    aria-current={active ? 'step' : undefined}
                    className={`w-36 shrink-0 text-left p-1.5 rounded-xl border transition-all cursor-pointer ${
                      active
                        ? 'bg-indigo-50/70 border-indigo-600 ring-1 ring-indigo-600'
                        : 'bg-slate-50/50 border-slate-200/80 hover:border-slate-300'
                    }`}
                  >
                    {renderSlideThumbnail(s)}
                    <div className="mt-1.5 flex items-center gap-1.5 px-0.5">
                      <span
                        className={`font-mono tabular-nums text-[10px] font-semibold shrink-0 ${
                          active ? 'text-indigo-700' : 'text-slate-400'
                        }`}
                      >
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span
                        className={`text-[11px] truncate ${
                          active
                            ? 'text-indigo-900 font-semibold'
                            : 'text-slate-700 font-medium'
                        }`}
                      >
                        {s.title}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Speaker Notes + Bottom Navigation */}
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-3 items-center">
            <div className="bg-white border border-slate-200 rounded-xl px-4 py-2.5">
              <label
                htmlFor="speaker-notes"
                className="block text-[11px] font-semibold text-slate-500 mb-1"
              >
                {t.speakerNotesLabel}
              </label>
              <input
                id="speaker-notes"
                type="text"
                value={currentSlide.speakerNotes || ''}
                onChange={(e) =>
                  updateCurrentSlide({ speakerNotes: e.target.value })
                }
                placeholder={t.speakerNotesPlaceholder}
                className="w-full text-xs text-slate-700 bg-transparent outline-none placeholder:text-slate-400"
              />
            </div>

            <div className="flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={prevSlide}
                disabled={isFirst}
                aria-label={t.previousSlide}
                className={`p-2.5 rounded-xl border border-slate-200 transition-colors cursor-pointer ${
                  isFirst
                    ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
                    : 'bg-white text-slate-800 hover:bg-slate-50'
                }`}
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowThemeSelector(!showThemeSelector)}
                  className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 px-4 py-2.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <span
                    className="w-3 h-3 rounded-full border border-slate-300"
                    style={{ backgroundColor: activeTheme.colors.primary }}
                  />
                  <span>
                    {t.themeSelector}: {activeTheme.name}
                  </span>
                  <Palette className="w-3.5 h-3.5 text-slate-500" />
                </button>

                {showThemeSelector && (
                  <div className="absolute bottom-full right-0 mb-2 bg-white rounded-xl shadow-lg border border-slate-200 p-2 w-56 z-50">
                    <div className="grid gap-1">
                      {Object.values(THEMES).map((themeOption) => (
                        <button
                          key={themeOption.id}
                          type="button"
                          onClick={() => {
                            const validated = getTheme(themeOption.id);
                            setActiveTheme(validated);
                            onThemeChange?.(validated);
                            setShowThemeSelector(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                            activeTheme.id === themeOption.id
                              ? 'bg-indigo-600 text-white'
                              : 'hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <span>{themeOption.name}</span>
                          <div className="flex gap-1">
                            <span
                              className="w-2.5 h-2.5 rounded-full border border-black/15"
                              style={{
                                backgroundColor: themeOption.colors.primary,
                              }}
                            />
                            <span
                              className="w-2.5 h-2.5 rounded-full border border-black/15"
                              style={{
                                backgroundColor: themeOption.colors.background,
                              }}
                            />
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <button
                type="button"
                onClick={nextSlide}
                disabled={isLast}
                aria-label={t.nextSlide}
                className={`p-2.5 rounded-xl border border-slate-200 transition-colors cursor-pointer ${
                  isLast
                    ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
                    : 'bg-indigo-600 text-white border-indigo-600 hover:bg-indigo-700'
                }`}
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
