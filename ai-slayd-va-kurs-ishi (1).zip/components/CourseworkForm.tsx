import React, { useEffect, useState } from 'react';
import { ArrowRight, BookOpen, FileText, Globe, Layers, ListOrdered } from 'lucide-react';
import type { CourseMeta, CourseSettings, Language } from '../types';
import { translations } from '../utils/translations';
import { DEFAULT_MINISTRY } from '../utils/docxGenerator';

interface CourseworkFormProps {
  onGenerate: (settings: CourseSettings) => void;
  onLanguageChange: (lang: Language) => void;
  currentLang: Language;
}

const inputClass =
  'w-full px-4 py-3 rounded-xl border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none transition-all text-sm md:text-base placeholder:text-slate-400';
const smallInputClass =
  'w-full px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none transition-all text-sm placeholder:text-slate-400';

export const CourseworkForm: React.FC<CourseworkFormProps> = ({
  onGenerate,
  onLanguageChange,
  currentLang,
}) => {
  const t = translations[currentLang];

  const [topic, setTopic] = useState('');
  const [pages, setPages] = useState(30);
  const [chapterCount, setChapterCount] = useState(3);
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [meta, setMeta] = useState<CourseMeta>({
    ministry: DEFAULT_MINISTRY[currentLang],
    university: '',
    faculty: '',
    subjectName: '',
    student: '',
    group: '',
    supervisor: '',
    city: '',
    year: String(new Date().getFullYear()),
  });

  // Keep the default ministry line in sync with the language unless the user changed it.
  useEffect(() => {
    setMeta((prev) => {
      const isDefault = Object.values(DEFAULT_MINISTRY).includes(prev.ministry) || !prev.ministry;
      return isDefault ? { ...prev, ministry: DEFAULT_MINISTRY[currentLang] } : prev;
    });
  }, [currentLang]);

  const setField = (key: keyof CourseMeta) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setMeta((prev) => ({ ...prev, [key]: e.target.value }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim().length < 3) return;
    onGenerate({
      topic: topic.trim(),
      pages,
      chapterCount,
      language: currentLang,
      additionalInfo: additionalInfo.trim() || undefined,
      meta: { ...meta, subjectName: meta.subjectName.trim() },
    });
  };

  const canSubmit = topic.trim().length >= 3;

  return (
    <div className="w-full max-w-2xl mx-auto p-6 md:p-10 bg-white rounded-2xl border border-slate-200 shadow-sm">
      <div className="mb-8">
        <div className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-indigo-50 text-indigo-600 mb-4 border border-indigo-100">
          <BookOpen className="w-5 h-5" />
        </div>
        <h1 className="font-display text-2xl md:text-3xl font-bold text-slate-900 tracking-tight mb-2 [text-wrap:balance]">
          {t.cwHeaderTitle}
        </h1>
        <p className="text-sm md:text-base text-slate-600 leading-relaxed">{t.cwSubtitle}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label htmlFor="cw-topic" className="block text-sm font-semibold text-slate-800 mb-2">
            {t.cwTopicLabel}
          </label>
          <input
            id="cw-topic"
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={t.cwTopicPlaceholder}
            maxLength={300}
            required
            className={inputClass}
          />
        </div>

        <div>
          <label htmlFor="cw-subject" className="block text-sm font-semibold text-slate-800 mb-2">
            {t.cwSubjectLabel}
          </label>
          <input
            id="cw-subject"
            type="text"
            value={meta.subjectName}
            onChange={setField('subjectName')}
            placeholder={t.cwSubjectPlaceholder}
            maxLength={200}
            className={inputClass}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label
              htmlFor="cw-language"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>{t.inputLangLabel}</span>
            </label>
            <select
              id="cw-language"
              value={currentLang}
              onChange={(e) => onLanguageChange(e.target.value as Language)}
              className="w-full px-3 py-2.5 bg-white text-slate-900 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none cursor-pointer text-sm"
            >
              <option value="uz">O'zbek</option>
              <option value="en">English</option>
              <option value="ru">Русский</option>
            </select>
          </div>

          <div>
            <label
              htmlFor="cw-pages"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2"
            >
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              <span>{t.cwPagesLabel}</span>
            </label>
            <select
              id="cw-pages"
              value={pages}
              onChange={(e) => setPages(Number(e.target.value))}
              className="w-full px-3 py-2.5 bg-white text-slate-900 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none cursor-pointer text-sm tabular-nums"
            >
              {[20, 25, 30, 35, 40].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="cw-chapters"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 mb-2"
            >
              <ListOrdered className="w-3.5 h-3.5 text-slate-500" />
              <span>{t.cwChaptersLabel}</span>
            </label>
            <select
              id="cw-chapters"
              value={chapterCount}
              onChange={(e) => setChapterCount(Number(e.target.value))}
              className="w-full px-3 py-2.5 bg-white text-slate-900 rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 outline-none cursor-pointer text-sm tabular-nums"
            >
              {[2, 3, 4].map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label
            htmlFor="cw-extra"
            className="flex items-center gap-1.5 text-sm font-semibold text-slate-800 mb-2"
          >
            <FileText className="w-4 h-4 text-slate-500" />
            <span>{t.cwExtraLabel}</span>
          </label>
          <textarea
            id="cw-extra"
            value={additionalInfo}
            onChange={(e) => setAdditionalInfo(e.target.value)}
            placeholder={t.cwExtraPlaceholder}
            maxLength={1000}
            rows={3}
            className={`${inputClass} resize-none`}
          />
        </div>

        <details className="rounded-xl border border-slate-200 bg-slate-50/60 open:bg-white">
          <summary className="cursor-pointer select-none px-4 py-3 text-sm font-semibold text-slate-800">
            {t.cwTitlePageLegend}
          </summary>
          <div className="px-4 pb-4 pt-1 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwMinistry}</label>
              <input type="text" value={meta.ministry} onChange={setField('ministry')} className={smallInputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwUniversity}</label>
              <input type="text" value={meta.university} onChange={setField('university')} className={smallInputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwFaculty}</label>
              <input type="text" value={meta.faculty} onChange={setField('faculty')} className={smallInputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwStudent}</label>
              <input type="text" value={meta.student} onChange={setField('student')} className={smallInputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwGroup}</label>
              <input type="text" value={meta.group} onChange={setField('group')} className={smallInputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwSupervisor}</label>
              <input type="text" value={meta.supervisor} onChange={setField('supervisor')} className={smallInputClass} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwCity}</label>
                <input type="text" value={meta.city} onChange={setField('city')} className={smallInputClass} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.cwYear}</label>
                <input type="text" value={meta.year} onChange={setField('year')} maxLength={4} className={`${smallInputClass} tabular-nums`} />
              </div>
            </div>
          </div>
        </details>

        <button
          type="submit"
          disabled={!canSubmit}
          className={`w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl text-white font-semibold text-sm md:text-base transition-all whitespace-nowrap ${
            canSubmit
              ? 'bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] cursor-pointer shadow-sm'
              : 'bg-slate-300 text-slate-500 cursor-not-allowed'
          }`}
        >
          <span>{t.cwBtnGenerate}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
