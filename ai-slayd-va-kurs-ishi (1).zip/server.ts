import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type { CourseOutline, Language, Slide } from './types.ts';
import {
  SYSTEM_INSTRUCTION_PLAN,
  createPlanPrompt,
  createRefineSlidePrompt,
} from './utils/prompts.ts';
import {
  SYSTEM_INSTRUCTION_COURSE,
  createCourseOutlinePrompt,
  createCoursePartPrompt,
} from './utils/courseworkPrompts.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const MODEL_NAME = 'gemini-3.1-flash-lite';
const FALLBACK_MODEL_NAME = 'gemini-4-hydrogen';
const ALLOWED_LANGUAGES = new Set<Language>(['uz', 'en', 'ru']);
const ALLOWED_THEMES = [
  'modern_blue',
  'nature_green',
  'creative_purple',
  'minimal_dark',
  'midnight_gold',
  'soft_rose',
  'tech_cyan',
];
const ALLOWED_LAYOUTS = [
  'title',
  'split_left',
  'split_right',
  'minimal_typography',
  'timeline_flow',
  'comparison_grid',
  'editorial_spotlight',
];
const ALLOWED_VISUAL_KINDS = [
  'stat',
  'steps',
  'highlights',
  'quote',
  'timeline',
  'comparison',
];
const ALLOWED_MOTIFS = ['orbital', 'waves', 'nodes', 'peaks', 'grid', 'prism'];

const getAiClient = (): GoogleGenAI => {
  const apiKey =
    process.env.GEMINI_API_KEY?.trim() || process.env.API_KEY?.trim();
  if (!apiKey) {
    const err = new Error(
      'Gemini API key is not configured on the server. Add GEMINI_API_KEY in Settings > Secrets.'
    ) as Error & { status?: number; code?: string };
    err.status = 503;
    err.code = 'MISSING_API_KEY';
    throw err;
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

const extractStatus = (err: unknown): number => {
  if (typeof err === 'object' && err !== null) {
    const maybeErr = err as { status?: number; statusCode?: number; code?: number | string };
    if (typeof maybeErr.status === 'number') return maybeErr.status;
    if (typeof maybeErr.statusCode === 'number') return maybeErr.statusCode;
    if (typeof maybeErr.code === 'number') return maybeErr.code;
  }
  return 500;
};

const isMissingApiKeyError = (err: unknown): boolean => {
  if (typeof err === 'object' && err !== null && 'code' in err) {
    return (err as { code?: unknown }).code === 'MISSING_API_KEY';
  }
  return false;
};

const withRetry = async <T>(fn: () => Promise<T>, maxAttempts = 3): Promise<T> => {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      if (isMissingApiKeyError(err)) {
        throw err;
      }
      const status = extractStatus(err);
      const isRetryable = status === 429 || status >= 500;
      if (!isRetryable || attempt === maxAttempts) {
        throw err;
      }
      await sleep(350 * Math.pow(2, attempt - 1));
    }
  }
  throw lastError;
};

const isQuotaOrRateLimit = (err: unknown): boolean => {
  const status = extractStatus(err);
  const msg = err instanceof Error ? err.message : String(err);
  return status === 429 || msg.includes('RESOURCE_EXHAUSTED');
};

const shouldFallbackModel = (err: unknown): boolean => {
  if (isMissingApiKeyError(err)) return false;
  const status = extractStatus(err);
  const msg = err instanceof Error ? err.message : String(err);
  return isQuotaOrRateLimit(err) || status === 503 || msg.includes('UNAVAILABLE');
};

const formatGeminiError = (err: unknown): { status: number; message: string } => {
  const status = extractStatus(err);
  const rawMessage = err instanceof Error ? err.message : String(err);

  if (isMissingApiKeyError(err)) {
    return {
      status: 503,
      message:
        'Gemini API key is not configured on the server. Add GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (
    status === 401 ||
    status === 403 ||
    rawMessage.includes('API_KEY_INVALID') ||
    rawMessage.includes('PERMISSION_DENIED') ||
    rawMessage.toLowerCase().includes('api key')
  ) {
    return {
      status: status === 403 ? 403 : 401,
      message:
        'Gemini API authentication failed. Please verify GEMINI_API_KEY in Settings > Secrets.',
    };
  }
  if (status === 400) {
    return {
      status: 400,
      message:
        'Gemini rejected the request parameters. Please adjust the topic or try again.',
    };
  }
  if (status === 404 || rawMessage.includes('NOT_FOUND')) {
    return {
      status: 502,
      message: `Configured Gemini model (${MODEL_NAME}) is unavailable.`,
    };
  }
  if (isQuotaOrRateLimit(err)) {
    return {
      status: 429,
      message:
        'Gemini API quota or rate limit reached. Please wait a moment or check your billing-enabled API key in Settings > Secrets.',
    };
  }
  if (status === 503 || rawMessage.includes('UNAVAILABLE')) {
    return {
      status: 503,
      message: 'Gemini service is temporarily busy. Please try again in a moment.',
    };
  }
  if (err instanceof SyntaxError) {
    return {
      status: 502,
      message: 'Gemini returned malformed JSON. Please try generating again.',
    };
  }

  return {
    status: status >= 400 && status < 600 ? status : 500,
    message: 'Could not complete AI generation. Please try again.',
  };
};

const stripJsonFences = (text: string): string => {
  const trimmed = text.trim();
  if (trimmed.startsWith('```')) {
    return trimmed
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/\s*```$/, '')
      .trim();
  }
  return trimmed;
};

const generateWithModelFallback = async <T>(
  label: string,
  runWithModel: (model: string) => Promise<T>
): Promise<{ result: T; model: string }> => {
  try {
    const result = await withRetry(() => runWithModel(MODEL_NAME), 2);
    return { result, model: MODEL_NAME };
  } catch (primaryErr) {
    if (shouldFallbackModel(primaryErr)) {
      console.log(`[${label}] Switching to fallback model (${FALLBACK_MODEL_NAME})`);
      const result = await withRetry(() => runWithModel(FALLBACK_MODEL_NAME), 2);
      return { result, model: FALLBACK_MODEL_NAME };
    }
    throw primaryErr;
  }
};

const slideVisualSchema = {
  type: Type.OBJECT,
  properties: {
    kind: {
      type: Type.STRING,
      enum: ALLOWED_VISUAL_KINDS,
    },
    heading: { type: Type.STRING },
    items: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          label: { type: Type.STRING },
          value: { type: Type.STRING },
        },
        required: ['label', 'value'],
      },
    },
  },
  required: ['kind', 'heading', 'items'],
};

const slideSchema = {
  type: Type.OBJECT,
  properties: {
    sectionTag: { type: Type.STRING },
    title: { type: Type.STRING },
    content: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
    },
    layout: {
      type: Type.STRING,
      enum: ALLOWED_LAYOUTS,
    },
    visualMotif: {
      type: Type.STRING,
      enum: ALLOWED_MOTIFS,
    },
    visual: slideVisualSchema,
    speakerNotes: { type: Type.STRING },
  },
  required: [
    'sectionTag',
    'title',
    'content',
    'layout',
    'visualMotif',
    'visual',
    'speakerNotes',
  ],
};


const courseOutlineSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    chapters: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          sections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ['title', 'keyPoints'],
            },
          },
        },
        required: ['title', 'sections'],
      },
    },
  },
  required: ['title', 'chapters'],
};

const courseIntroSchema = {
  type: Type.OBJECT,
  properties: {
    relevance: { type: Type.STRING },
    goal: { type: Type.STRING },
    tasks: { type: Type.ARRAY, items: { type: Type.STRING } },
    object: { type: Type.STRING },
    subject: { type: Type.STRING },
    methods: { type: Type.STRING },
    structure: { type: Type.STRING },
  },
  required: ['relevance', 'goal', 'tasks', 'object', 'subject', 'methods', 'structure'],
};

const courseParagraphsSchema = {
  type: Type.OBJECT,
  properties: {
    paragraphs: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: ['paragraphs'],
};

const courseReferencesSchema = {
  type: Type.OBJECT,
  properties: {
    items: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: ['items'],
};

const asTrimmedString = (value: unknown, max = 600): string =>
  typeof value === 'string' ? value.trim().slice(0, max) : '';

const sanitizeOutline = (raw: unknown): CourseOutline | null => {
  if (typeof raw !== 'object' || raw === null) return null;
  const input = raw as { title?: unknown; chapters?: unknown };
  if (!Array.isArray(input.chapters) || input.chapters.length === 0 || input.chapters.length > 6) {
    return null;
  }
  const chapters = input.chapters.map((chapter: unknown) => {
    const ch = (chapter ?? {}) as { title?: unknown; sections?: unknown };
    const sections = Array.isArray(ch.sections) ? ch.sections.slice(0, 6) : [];
    return {
      title: asTrimmedString(ch.title, 300),
      sections: sections.map((section: unknown) => {
        const sec = (section ?? {}) as { title?: unknown; keyPoints?: unknown };
        return {
          title: asTrimmedString(sec.title, 300),
          keyPoints: Array.isArray(sec.keyPoints)
            ? sec.keyPoints.slice(0, 6).map((k: unknown) => asTrimmedString(k, 120)).filter(Boolean)
            : [],
        };
      }),
    };
  });
  if (chapters.some((c) => !c.title || c.sections.length === 0 || c.sections.some((x) => !x.title))) {
    return null;
  }
  return { title: asTrimmedString(input.title, 300), chapters };
};

const cleanParagraphs = (value: unknown): string[] =>
  Array.isArray(value)
    ? value
        .filter((p: unknown): p is string => typeof p === 'string')
        .map((p) => p.replace(/\*\*|__|^#+\s*/g, '').replace(/\s+/g, ' ').trim())
        .filter((p) => p.length > 0)
    : [];

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  app.get('/api/health', (_req, res) => {
    const hasApiKey = Boolean(
      process.env.GEMINI_API_KEY?.trim() || process.env.API_KEY?.trim()
    );
    res.json({ ok: true, hasApiKey, model: MODEL_NAME });
  });

  app.post('/api/presentation/plan', async (req, res) => {
    try {
      const { topic, slideCount, planCount, language, additionalInfo } = req.body ?? {};

      if (typeof topic !== 'string' || topic.trim().length < 2 || topic.trim().length > 300) {
        res.status(400).json({ error: 'Topic must be between 2 and 300 characters.' });
        return;
      }

      const parsedSlides = Number(slideCount);
      if (!Number.isInteger(parsedSlides) || parsedSlides < 3 || parsedSlides > 30) {
        res.status(400).json({ error: 'Slide count must be an integer between 3 and 30.' });
        return;
      }

      const parsedPlans = Number(planCount);
      if (!Number.isInteger(parsedPlans) || parsedPlans < 2 || parsedPlans > 8) {
        res.status(400).json({ error: 'Plan count must be an integer between 2 and 8.' });
        return;
      }

      const selectedLang: Language = ALLOWED_LANGUAGES.has(language) ? language : 'uz';
      const safeInfo =
        typeof additionalInfo === 'string' ? additionalInfo.trim().slice(0, 1000) : undefined;

      const ai = getAiClient();
      const startedAt = Date.now();
      console.log(`[plan] Generating ${parsedSlides} slides in ${selectedLang}`);

      const { result: response, model: usedModel } = await generateWithModelFallback(
        'plan',
        (model) =>
          ai.models.generateContent({
            model,
            contents: createPlanPrompt(
              topic.trim(),
              parsedSlides,
              parsedPlans,
              selectedLang,
              safeInfo
            ),
            config: {
              systemInstruction: SYSTEM_INSTRUCTION_PLAN(selectedLang),
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  themeId: { type: Type.STRING, enum: ALLOWED_THEMES },
                  slides: {
                    type: Type.ARRAY,
                    items: slideSchema,
                  },
                },
                required: ['themeId', 'slides'],
              },
            },
          })
      );

      console.log(`[plan] Gemini (${usedModel}) responded in ${Date.now() - startedAt}ms`);
      const jsonText = stripJsonFences(response.text ?? '');
      if (!jsonText) {
        res.status(502).json({ error: 'Received an empty response from Gemini.' });
        return;
      }

      const parsedRaw: unknown = JSON.parse(jsonText);
      if (typeof parsedRaw !== 'object' || parsedRaw === null || Array.isArray(parsedRaw)) {
        res.status(502).json({ error: 'Received an invalid plan format from Gemini.' });
        return;
      }

      const parsed = parsedRaw as { themeId?: unknown; slides?: unknown };
      const resolvedThemeId =
        typeof parsed.themeId === 'string' && ALLOWED_THEMES.includes(parsed.themeId)
          ? parsed.themeId
          : 'modern_blue';
      const slides = Array.isArray(parsed.slides) ? (parsed.slides as Slide[]) : [];

      if (slides.length === 0) {
        res.status(502).json({ error: 'Gemini returned an empty slide list. Please retry.' });
        return;
      }

      res.json({
        themeId: resolvedThemeId,
        slides,
        usageStats: {
          model: usedModel,
          inputTokens: response.usageMetadata?.promptTokenCount || 0,
          outputTokens: response.usageMetadata?.candidatesTokenCount || 0,
          totalTokens: response.usageMetadata?.totalTokenCount || 0,
        },
      });
    } catch (err) {
      const formatted = formatGeminiError(err);
      console.error(`[plan] Failed (${formatted.status}):`, formatted.message);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/presentation/refine-slide', async (req, res) => {
    try {
      const { topic, slide, instruction, language } = req.body ?? {};

      if (typeof topic !== 'string' || !topic.trim()) {
        res.status(400).json({ error: 'Topic is required.' });
        return;
      }
      if (!slide || typeof slide.title !== 'string' || !Array.isArray(slide.content)) {
        res.status(400).json({ error: 'Valid slide data is required.' });
        return;
      }
      if (typeof instruction !== 'string' || !instruction.trim() || instruction.length > 300) {
        res.status(400).json({ error: 'Valid refinement instruction is required.' });
        return;
      }

      const sanitizedSlide: Slide = {
        title: slide.title,
        sectionTag: typeof slide.sectionTag === 'string' ? slide.sectionTag : undefined,
        content: slide.content.filter((item: unknown): item is string => typeof item === 'string'),
        layout: slide.layout,
        visual: slide.visual,
        visualMotif: slide.visualMotif,
        speakerNotes: typeof slide.speakerNotes === 'string' ? slide.speakerNotes : undefined,
      };

      const selectedLang: Language = ALLOWED_LANGUAGES.has(language) ? language : 'uz';
      const ai = getAiClient();

      const { result: response } = await generateWithModelFallback(
        'refine',
        (model) =>
          ai.models.generateContent({
            model,
            contents: createRefineSlidePrompt(
              topic.trim().slice(0, 300),
              sanitizedSlide,
              instruction.trim(),
              selectedLang
            ),
            config: {
              systemInstruction: SYSTEM_INSTRUCTION_PLAN(selectedLang),
              thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
              responseMimeType: 'application/json',
              responseSchema: slideSchema,
            },
          })
      );

      const jsonText = stripJsonFences(response.text ?? '');
      if (!jsonText) {
        res.status(502).json({ error: 'Received an empty response from Gemini.' });
        return;
      }

      const refinedRaw: unknown = JSON.parse(jsonText);
      if (typeof refinedRaw !== 'object' || refinedRaw === null || Array.isArray(refinedRaw)) {
        res.status(502).json({ error: 'Received an invalid slide format from Gemini.' });
        return;
      }

      res.json({ slide: refinedRaw as Slide });
    } catch (err) {
      const formatted = formatGeminiError(err);
      console.error(`[refine] Failed (${formatted.status}):`, formatted.message);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });


  app.post('/api/coursework/outline', async (req, res) => {
    try {
      const { topic, pages, chapterCount, language, additionalInfo } = req.body ?? {};

      if (typeof topic !== 'string' || topic.trim().length < 3 || topic.trim().length > 300) {
        res.status(400).json({ error: 'Topic must be between 3 and 300 characters.' });
        return;
      }
      const parsedPages = Number(pages);
      if (!Number.isInteger(parsedPages) || parsedPages < 15 || parsedPages > 60) {
        res.status(400).json({ error: 'Page count must be an integer between 15 and 60.' });
        return;
      }
      const parsedChapters = Number(chapterCount);
      if (!Number.isInteger(parsedChapters) || parsedChapters < 2 || parsedChapters > 4) {
        res.status(400).json({ error: 'Chapter count must be an integer between 2 and 4.' });
        return;
      }

      const selectedLang: Language = ALLOWED_LANGUAGES.has(language) ? language : 'uz';
      const safeInfo =
        typeof additionalInfo === 'string' ? additionalInfo.trim().slice(0, 1000) : undefined;
      const sectionsPerChapter = parsedPages <= 25 ? 2 : 3;

      const ai = getAiClient();
      console.log(`[coursework/outline] ${parsedPages} pages, ${parsedChapters} chapters, ${selectedLang}`);

      const { result: response } = await generateWithModelFallback('coursework-outline', (model) =>
        ai.models.generateContent({
          model,
          contents: createCourseOutlinePrompt(
            topic.trim(),
            parsedPages,
            parsedChapters,
            sectionsPerChapter,
            selectedLang,
            safeInfo
          ),
          config: {
            systemInstruction: SYSTEM_INSTRUCTION_COURSE(selectedLang),
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: courseOutlineSchema,
          },
        })
      );

      const jsonText = stripJsonFences(response.text ?? '');
      if (!jsonText) {
        res.status(502).json({ error: 'Received an empty response from Gemini.' });
        return;
      }
      const outline = sanitizeOutline(JSON.parse(jsonText));
      if (!outline) {
        res.status(502).json({ error: 'Gemini returned an invalid course structure. Please retry.' });
        return;
      }
      if (!outline.title) outline.title = topic.trim();
      res.json({ outline });
    } catch (err) {
      const formatted = formatGeminiError(err);
      console.error(`[coursework/outline] Failed (${formatted.status}):`, formatted.message);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post('/api/coursework/part', async (req, res) => {
    try {
      const {
        kind,
        topic,
        subject,
        language,
        outline: rawOutline,
        chapterIndex,
        sectionIndex,
        targetWords,
        existing,
        additionalInfo,
      } = req.body ?? {};

      if (!['intro', 'section', 'conclusion', 'references'].includes(kind)) {
        res.status(400).json({ error: 'Unknown course work part.' });
        return;
      }
      if (typeof topic !== 'string' || topic.trim().length < 3 || topic.trim().length > 300) {
        res.status(400).json({ error: 'Topic must be between 3 and 300 characters.' });
        return;
      }
      const outline = sanitizeOutline(rawOutline);
      if (!outline) {
        res.status(400).json({ error: 'Valid course structure is required.' });
        return;
      }

      let ci = 0;
      let si = 0;
      if (kind === 'section') {
        ci = Number(chapterIndex);
        si = Number(sectionIndex);
        if (
          !Number.isInteger(ci) ||
          !Number.isInteger(si) ||
          !outline.chapters[ci] ||
          !outline.chapters[ci].sections[si]
        ) {
          res.status(400).json({ error: 'Valid chapter and section index are required.' });
          return;
        }
      }

      const selectedLang: Language = ALLOWED_LANGUAGES.has(language) ? language : 'uz';
      const words = Math.min(1100, Math.max(150, Math.round(Number(targetWords) || 500)));
      const safeExisting = Array.isArray(existing)
        ? existing.filter((p: unknown): p is string => typeof p === 'string').slice(0, 20)
        : [];
      const safeInfo =
        typeof additionalInfo === 'string' ? additionalInfo.trim().slice(0, 1000) : undefined;

      const ai = getAiClient();
      console.log(`[coursework/part] ${kind}${kind === 'section' ? ` ${ci + 1}.${si + 1}` : ''} (${words}w)`);

      const schema =
        kind === 'intro'
          ? courseIntroSchema
          : kind === 'references'
            ? courseReferencesSchema
            : courseParagraphsSchema;

      const { result: response } = await generateWithModelFallback('coursework-part', (model) =>
        ai.models.generateContent({
          model,
          contents: createCoursePartPrompt({
            kind,
            topic: topic.trim(),
            subject: asTrimmedString(subject, 200),
            language: selectedLang,
            outline,
            chapterIndex: ci,
            sectionIndex: si,
            targetWords: words,
            existing: safeExisting,
            additionalInfo: safeInfo,
          }),
          config: {
            systemInstruction: SYSTEM_INSTRUCTION_COURSE(selectedLang),
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            responseMimeType: 'application/json',
            responseSchema: schema,
            maxOutputTokens: 8192,
          },
        })
      );

      const jsonText = stripJsonFences(response.text ?? '');
      if (!jsonText) {
        res.status(502).json({ error: 'Received an empty response from Gemini.' });
        return;
      }
      const parsed = JSON.parse(jsonText) as Record<string, unknown>;

      if (kind === 'intro') {
        const intro = {
          relevance: asTrimmedString(parsed.relevance, 4000),
          goal: asTrimmedString(parsed.goal, 1000),
          tasks: cleanParagraphs(parsed.tasks),
          object: asTrimmedString(parsed.object, 1000),
          subject: asTrimmedString(parsed.subject, 1000),
          methods: asTrimmedString(parsed.methods, 1500),
          structure: asTrimmedString(parsed.structure, 3000),
        };
        if (!intro.relevance || !intro.goal || intro.tasks.length === 0) {
          res.status(502).json({ error: 'Gemini returned an incomplete introduction. Please retry.' });
          return;
        }
        res.json({ intro });
        return;
      }

      if (kind === 'references') {
        const items = cleanParagraphs(parsed.items).map((item) =>
          item.replace(/^\s*(?:\d+[.)]\s*)/, '')
        );
        res.json({ items });
        return;
      }

      const paragraphs = cleanParagraphs(parsed.paragraphs);
      if (paragraphs.length === 0) {
        res.status(502).json({ error: 'Gemini returned an empty text. Please retry.' });
        return;
      }
      res.json({ paragraphs });
    } catch (err) {
      const formatted = formatGeminiError(err);
      console.error(`[coursework/part] Failed (${formatted.status}):`, formatted.message);
      res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.all('/api/{*splat}', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  app.use(
    (
      err: unknown,
      req: express.Request,
      res: express.Response,
      next: express.NextFunction
    ) => {
      if (res.headersSent) {
        next(err);
        return;
      }
      const maybeErr = err as { status?: number; statusCode?: number; type?: string };
      const status = maybeErr?.status ?? maybeErr?.statusCode;
      if (status === 413 || maybeErr?.type === 'entity.too.large') {
        res.status(413).json({
          error:
            'Request payload is too large (maximum 10 MB). Uploaded images remain in your browser and are excluded from AI refinement.',
        });
        return;
      }
      if (maybeErr?.type === 'entity.parse.failed' || err instanceof SyntaxError) {
        res.status(400).json({ error: 'Invalid JSON request body.' });
        return;
      }
      if (req.path.startsWith('/api/')) {
        res.status(status && status >= 400 && status < 600 ? status : 500).json({
          error: 'Unexpected server error while processing API request.',
        });
        return;
      }
      next(err);
    }
  );

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
