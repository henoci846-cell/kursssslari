import React, { useRef, useState } from 'react';
import { InputForm } from './components/InputForm';
import { LoadingView } from './components/LoadingView';
import { SlideViewer } from './components/SlideViewer';
import { CourseworkForm } from './components/CourseworkForm';
import { CourseworkLoading } from './components/CourseworkLoading';
import { CourseworkViewer } from './components/CourseworkViewer';
import { generatePresentationPlan } from './services/geminiService';
import { generateCourseWork } from './services/courseworkService';
import {
  AppMode,
  AppStatus,
  CourseProgress,
  CourseSettings,
  CourseWork,
  Slide,
  Theme,
  Language,
} from './types';
import { getTheme, loadSavedTheme, resolveTheme, saveThemeId } from './utils/themes';
import { translations } from './utils/translations';
import { AlertCircle } from 'lucide-react';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppStatus>(AppStatus.IDLE);
  const [topic, setTopic] = useState<string>('');
  const [slides, setSlides] = useState<Slide[]>([]);
  const [theme, setTheme] = useState<Theme>(() => loadSavedTheme());
  const [error, setError] = useState<string | null>(null);
  const [language, setLanguage] = useState<Language>('uz');
  const [mode, setMode] = useState<AppMode>('slides');
  const [courseWork, setCourseWork] = useState<CourseWork | null>(null);
  const [courseProgress, setCourseProgress] = useState<CourseProgress>({
    done: 0,
    total: 1,
    label: 'outline',
  });
  const abortRef = useRef<AbortController | null>(null);

  const safeTheme = resolveTheme(theme);

  const handleThemeChange = (nextTheme: Theme) => {
    const validTheme = resolveTheme(nextTheme);
    setTheme(validTheme);
    saveThemeId(validTheme.id);
  };

  const handleGenerate = async (
    inputTopic: string,
    slideCount: number,
    planCount: number,
    selectedLang: Language,
    additionalInfo?: string
  ) => {
    setTopic(inputTopic);
    setStatus(AppStatus.GENERATING_PLAN);
    setError(null);
    setSlides([]);

    try {
      const planResponse = await generatePresentationPlan(
        inputTopic,
        slideCount,
        planCount,
        selectedLang,
        additionalInfo
      );

      if (!planResponse || typeof planResponse !== 'object') {
        throw new Error(translations[selectedLang].errorTitle);
      }

      const nextTheme = getTheme(planResponse.themeId);
      setTheme(nextTheme);
      saveThemeId(nextTheme.id);
      setSlides(Array.isArray(planResponse.slides) ? planResponse.slides : []);
      setStatus(AppStatus.READY);
    } catch (err) {
      const message =
        err instanceof Error && err.message
          ? err.message
          : translations[selectedLang].errorTitle;
      setError(message);
      setStatus(AppStatus.ERROR);
    }
  };

  const handleGenerateCourseWork = async (settings: CourseSettings) => {
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setStatus(AppStatus.GENERATING_PLAN);
    setError(null);
    setCourseWork(null);
    setCourseProgress({ done: 0, total: 1, label: 'outline' });

    try {
      const result = await generateCourseWork(settings, setCourseProgress, controller.signal);
      if (controller.signal.aborted) return;
      setCourseWork(result);
      setStatus(AppStatus.READY);
    } catch (err) {
      if (controller.signal.aborted) return;
      const message =
        err instanceof Error && err.message ? err.message : translations[settings.language].errorTitle;
      setError(message);
      setStatus(AppStatus.ERROR);
    }
  };

  const handleRestart = () => {
    abortRef.current?.abort();
    setStatus(AppStatus.IDLE);
    setSlides([]);
    setCourseWork(null);
    setError(null);
  };

  const handleModeChange = (nextMode: AppMode) => {
    if (nextMode === mode) return;
    handleRestart();
    setMode(nextMode);
  };

  const t = translations[language];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <header className="bg-white border-b border-slate-200 px-6 py-3.5 flex items-center justify-between gap-8 sticky top-0 z-40">
        <button
          type="button"
          onClick={handleRestart}
          className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-indigo-600 transition-colors cursor-pointer"
        >
          {mode === 'coursework' ? t.cwHeaderTitle : t.headerTitle}
        </button>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0">
          {(['slides', 'coursework'] as AppMode[]).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => handleModeChange(m)}
              aria-pressed={mode === m}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                mode === m
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {m === 'slides' ? t.modeSlides : t.modeCourse}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0">
          {(['uz', 'en', 'ru'] as Language[]).map((lang) => (
            <button
              key={lang}
              type="button"
              onClick={() => setLanguage(lang)}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                language === lang
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang.toUpperCase()}
            </button>
          ))}
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-4 md:p-6 w-full">
        {mode === 'slides' && (
          <>
            {status === AppStatus.IDLE && (
              <InputForm
                onGenerate={handleGenerate}
                isProcessing={false}
                onLanguageChange={setLanguage}
                currentLang={language}
              />
            )}

            {status === AppStatus.GENERATING_PLAN && (
              <LoadingView status={status} language={language} />
            )}

            {status === AppStatus.READY && (
              <SlideViewer
                slides={slides}
                onSlidesChange={setSlides}
                topic={topic}
                theme={safeTheme}
                onThemeChange={handleThemeChange}
                onRestart={handleRestart}
                language={language}
              />
            )}
          </>
        )}

        {mode === 'coursework' && (
          <>
            {status === AppStatus.IDLE && (
              <CourseworkForm
                onGenerate={handleGenerateCourseWork}
                onLanguageChange={setLanguage}
                currentLang={language}
              />
            )}

            {status === AppStatus.GENERATING_PLAN && (
              <CourseworkLoading
                language={language}
                progress={courseProgress}
                onCancel={handleRestart}
              />
            )}

            {status === AppStatus.READY && courseWork && (
              <CourseworkViewer
                work={courseWork}
                onWorkChange={setCourseWork}
                onRestart={handleRestart}
                language={language}
              />
            )}
          </>
        )}

        {status === AppStatus.ERROR && (
          <div className="max-w-md w-full bg-white p-8 rounded-2xl border border-red-200 text-center shadow-sm">
            <AlertCircle className="w-10 h-10 text-red-600 mx-auto mb-4" />
            <p className="text-slate-700 mb-6 font-medium text-sm leading-relaxed">
              {error || t.errorTitle}
            </p>
            <button
              type="button"
              onClick={handleRestart}
              className="px-6 py-2.5 bg-indigo-600 text-white rounded-lg text-sm font-semibold hover:bg-indigo-700 transition-colors whitespace-nowrap cursor-pointer"
            >
              {t.btnRetry}
            </button>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
